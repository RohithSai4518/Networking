"""
Custom Binary PCAP Reader and Writer (Libpcap format)
Reads and writes standard .pcap captures without external C libraries.
"""

import struct
import time
from typing import List, Tuple, BinaryIO


# Standard PCAP Global Header Constants
PCAP_MAGIC_MICROSECONDS = 0xA1B2C3D4
PCAP_MAGIC_NANOSECONDS = 0xA1B23C4D
PCAP_VERSION_MAJOR = 2
PCAP_VERSION_MINOR = 4
LINKTYPE_ETHERNET = 1
LINKTYPE_RAW_IP = 101


class PcapWriter:
    """Writes raw packet frames into standard libpcap binary format."""

    def __init__(self, file_obj: BinaryIO, linktype: int = LINKTYPE_ETHERNET):
        self.file = file_obj
        self.linktype = linktype
        self._write_global_header()

    def _write_global_header(self):
        """Global Header: magic(4), v_maj(2), v_min(2), thiszone(4), sigfigs(4), snaplen(4), network(4)."""
        header = struct.pack(
            "=IHHiIII",
            PCAP_MAGIC_MICROSECONDS,
            PCAP_VERSION_MAJOR,
            PCAP_VERSION_MINOR,
            0,  # GMT to local correction
            0,  # accuracy of timestamps
            65535,  # max snaplen
            self.linktype,
        )
        self.file.write(header)
        self.file.flush()

    def write_packet(self, packet_bytes: bytes, timestamp: float = None):
        """Writes a single packet record with its 16-byte PCAP packet header."""
        if timestamp is None:
            timestamp = time.time()
        
        ts_sec = int(timestamp)
        ts_usec = int((timestamp - ts_sec) * 1_000_000)
        caplen = len(packet_bytes)
        origlen = caplen

        record_header = struct.pack("=IIII", ts_sec, ts_usec, caplen, origlen)
        self.file.write(record_header)
        self.file.write(packet_bytes)
        self.file.flush()


class PcapReader:
    """Parses and iterates over raw packets from a .pcap file."""

    def __init__(self, file_obj: BinaryIO):
        self.file = file_obj
        self.is_nano = False
        self.linktype = LINKTYPE_ETHERNET
        self._read_global_header()

    def _read_global_header(self):
        header_bytes = self.file.read(24)
        if len(header_bytes) < 24:
            raise ValueError("Invalid PCAP file: Header is too short.")

        magic = struct.unpack("=I", header_bytes[:4])[0]
        if magic == PCAP_MAGIC_MICROSECONDS:
            self.is_nano = False
        elif magic == PCAP_MAGIC_NANOSECONDS:
            self.is_nano = True
        elif magic == 0xD4C3B2A1:  # Byte-swapped
            self.is_nano = False
        else:
            raise ValueError(f"Unsupported PCAP magic number: 0x{magic:08x}")

        _, _, _, _, _, self.linktype = struct.unpack("=HHiIII", header_bytes[4:24])

    def read_packets(self) -> List[Tuple[float, bytes]]:
        """Reads all packets from PCAP file returning list of (timestamp, raw_bytes)."""
        packets = []
        while True:
            pkt_hdr = self.file.read(16)
            if len(pkt_hdr) < 16:
                break

            ts_sec, ts_frac, caplen, origlen = struct.unpack("=IIII", pkt_hdr)
            ts = ts_sec + (ts_frac / 1_000_000_000 if self.is_nano else ts_frac / 1_000_000)

            raw_data = self.file.read(caplen)
            if len(raw_data) < caplen:
                break

            packets.append((ts, raw_data))
        return packets
