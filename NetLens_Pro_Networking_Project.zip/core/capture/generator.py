"""
Synthetic Multi-Protocol Traffic Generator
Constructs realistic raw binary network frames for simulation, demonstration, and continuous stress testing.
"""

import random
import socket
import struct
import time
from typing import List, Tuple
from core.protocols.ipv4 import calculate_ipv4_checksum


def mac_to_bytes(mac_str: str) -> bytes:
    return bytes(int(b, 16) for b in mac_str.split(":"))


def ip_to_bytes(ip_str: str) -> bytes:
    return socket.inet_aton(ip_str)


def build_ethernet_header(src_mac: str, dst_mac: str, ethertype: int) -> bytes:
    return mac_to_bytes(dst_mac) + mac_to_bytes(src_mac) + struct.pack("!H", ethertype)


def build_ipv4_header(src_ip: str, dst_ip: str, proto: int, payload_len: int, ttl: int = 64) -> bytes:
    version_ihl = 0x45
    tos = 0
    total_len = 20 + payload_len
    ident = random.randint(1000, 65000)
    flags_frag = 0x4000  # DF set
    checksum = 0

    header_no_cs = struct.pack(
        "!BBHHHBBH",
        version_ihl,
        tos,
        total_len,
        ident,
        flags_frag,
        ttl,
        proto,
        checksum,
    ) + ip_to_bytes(src_ip) + ip_to_bytes(dst_ip)

    checksum = calculate_ipv4_checksum(header_no_cs)
    return struct.pack(
        "!BBHHHBBH",
        version_ihl,
        tos,
        total_len,
        ident,
        flags_frag,
        ttl,
        proto,
        checksum,
    ) + ip_to_bytes(src_ip) + ip_to_bytes(dst_ip)


def build_tcp_segment(
    src_port: int,
    dst_port: int,
    seq: int,
    ack: int,
    flags: int,
    payload: bytes = b"",
    window: int = 64240,
) -> bytes:
    offset_flags = (5 << 12) | (flags & 0x01FF)  # 5 32-bit words (20 bytes)
    checksum = 0
    urg_ptr = 0
    header = struct.pack(
        "!HHIIHHHH",
        src_port,
        dst_port,
        seq,
        ack,
        offset_flags,
        window,
        checksum,
        urg_ptr,
    )
    return header + payload


def build_udp_datagram(src_port: int, dst_port: int, payload: bytes) -> bytes:
    length = 8 + len(payload)
    checksum = 0
    header = struct.pack("!HHHH", src_port, dst_port, length, checksum)
    return header + payload


def build_dns_query(qname: str, qtype: int = 1, txn_id: int = None) -> bytes:
    if txn_id is None:
        txn_id = random.randint(1, 65535)
    flags = 0x0100  # Standard query, recursion desired
    header = struct.pack("!HHHHHH", txn_id, flags, 1, 0, 0, 0)

    # Encode domain name
    encoded_name = bytearray()
    for part in qname.split("."):
        if part:
            encoded_name.append(len(part))
            encoded_name.extend(part.encode("ascii"))
    encoded_name.append(0)

    q_tail = struct.pack("!HH", qtype, 1)  # Class IN
    return header + bytes(encoded_name) + q_tail


def build_dns_response(qname: str, answer_ip: str, txn_id: int = 0x1234) -> bytes:
    flags = 0x8180  # Standard query response, No error
    header = struct.pack("!HHHHHH", txn_id, flags, 1, 1, 0, 0)

    encoded_name = bytearray()
    for part in qname.split("."):
        if part:
            encoded_name.append(len(part))
            encoded_name.extend(part.encode("ascii"))
    encoded_name.append(0)

    q_tail = struct.pack("!HH", 1, 1)  # Type A, Class IN
    ans_header = bytes(encoded_name) + struct.pack("!HHIH", 1, 1, 300, 4) + ip_to_bytes(answer_ip)
    return header + bytes(encoded_name) + q_tail + ans_header


def build_arp_packet(op: int, sender_mac: str, sender_ip: str, target_mac: str, target_ip: str) -> bytes:
    htype = 1
    ptype = 0x0800
    hlen = 6
    plen = 4
    header = struct.pack("!HHBBH", htype, ptype, hlen, plen, op)
    return header + mac_to_bytes(sender_mac) + ip_to_bytes(sender_ip) + mac_to_bytes(target_mac) + ip_to_bytes(target_ip)


class TrafficGenerator:
    """Generates synthetic streams of multi-protocol packets."""

    SAMPLE_HOSTS = [
        "api.github.com",
        "cloudflare.com",
        "google.com",
        "aws.amazon.com",
        "cdn.netlens.internal",
        "metrics.telemetry.io",
    ]

    SAMPLE_IPS = [
        "192.168.1.10",
        "192.168.1.45",
        "192.168.1.102",
        "10.0.0.15",
        "172.16.0.8",
        "8.8.8.8",
        "1.1.1.1",
        "142.250.190.46",
        "104.244.42.1",
    ]

    SAMPLE_MACS = [
        "52:54:00:12:34:56",
        "00:1A:2B:3C:4D:5E",
        "F0:9F:C2:AB:CD:EF",
        "18:66:DA:22:33:44",
    ]

    def __init__(self):
        self.seq_counter = 1000

    def generate_random_packet(self) -> bytes:
        """Generates a random valid multi-layer packet from common traffic distributions."""
        choice = random.choices(
            ["http", "https", "dns", "icmp", "arp", "tcp_syn"],
            weights=[35, 25, 20, 10, 5, 5],
        )[0]

        if choice == "http":
            return self.generate_http_request()
        elif choice == "https":
            return self.generate_tls_handshake()
        elif choice == "dns":
            return self.generate_dns_traffic()
        elif choice == "icmp":
            return self.generate_icmp_ping()
        elif choice == "arp":
            return self.generate_arp_traffic()
        else:
            return self.generate_syn_packet()

    def generate_http_request(self) -> bytes:
        src_mac = random.choice(self.SAMPLE_MACS)
        dst_mac = "52:54:00:12:34:01"
        src_ip = random.choice(self.SAMPLE_IPS[:4])
        dst_ip = random.choice(self.SAMPLE_IPS[4:])
        src_port = random.randint(49152, 65535)
        dst_port = 80

        host = random.choice(self.SAMPLE_HOSTS)
        path = random.choice(["/", "/api/v1/status", "/metrics", "/index.html", "/healthz"])
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) NetLens/2.0"
        payload = f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: {user_agent}\r\nAccept: */*\r\n\r\n".encode("utf-8")

        tcp = build_tcp_segment(src_port, dst_port, self.seq_counter, 0, 0x018, payload)  # PSH+ACK
        self.seq_counter += len(payload)
        ip = build_ipv4_header(src_ip, dst_ip, 6, len(tcp))
        eth = build_ethernet_header(src_mac, dst_mac, 0x0800)
        return eth + ip + tcp

    def generate_tls_handshake(self) -> bytes:
        src_mac = random.choice(self.SAMPLE_MACS)
        dst_mac = "52:54:00:12:34:01"
        src_ip = random.choice(self.SAMPLE_IPS[:4])
        dst_ip = random.choice(self.SAMPLE_IPS[4:])
        src_port = random.randint(49152, 65535)
        dst_port = 443

        sni = random.choice(self.SAMPLE_HOSTS)
        sni_bytes = sni.encode("utf-8")

        # Construct minimal TLS 1.2 / 1.3 ClientHello record
        ext_sni = struct.pack("!HH", 0, len(sni_bytes) + 5) + struct.pack("!HBH", len(sni_bytes) + 3, 0, len(sni_bytes)) + sni_bytes
        ciphers = b"\x00\x04\x13\x01\x13\x02"  # TLS_AES_128_GCM_SHA256, TLS_AES_256_GCM_SHA384
        handshake_body = (
            b"\x03\x03"  # TLS 1.2 version
            + (b"\x01" * 32)  # Random
            + b"\x00"  # Session ID length 0
            + struct.pack("!H", len(ciphers)) + ciphers
            + b"\x01\x00"  # Compression methods (1 byte len, null compression)
            + struct.pack("!H", len(ext_sni)) + ext_sni
        )

        hs_header = struct.pack("!B", 1) + int(len(handshake_body)).to_bytes(3, "big") + handshake_body
        tls_record = struct.pack("!BHH", 22, 0x0303, len(hs_header)) + hs_header

        tcp = build_tcp_segment(src_port, dst_port, self.seq_counter, 0, 0x018, tls_record)
        ip = build_ipv4_header(src_ip, dst_ip, 6, len(tcp))
        eth = build_ethernet_header(src_mac, dst_mac, 0x0800)
        return eth + ip + tcp

    def generate_dns_traffic(self) -> bytes:
        src_mac = random.choice(self.SAMPLE_MACS)
        dst_mac = "52:54:00:12:34:01"
        src_ip = random.choice(self.SAMPLE_IPS[:4])
        dst_ip = "8.8.8.8"
        src_port = random.randint(49152, 65535)
        dst_port = 53

        domain = random.choice(self.SAMPLE_HOSTS)
        if random.random() < 0.5:
            dns_data = build_dns_query(domain, 1)
        else:
            dns_data = build_dns_response(domain, "93.184.216.34")

        udp = build_udp_datagram(src_port, dst_port, dns_data)
        ip = build_ipv4_header(src_ip, dst_ip, 17, len(udp))
        eth = build_ethernet_header(src_mac, dst_mac, 0x0800)
        return eth + ip + udp

    def generate_icmp_ping(self) -> bytes:
        src_mac = random.choice(self.SAMPLE_MACS)
        dst_mac = "52:54:00:12:34:01"
        src_ip = random.choice(self.SAMPLE_IPS[:4])
        dst_ip = "8.8.4.4"

        icmp_type = 8  # Echo Request
        seq = random.randint(1, 100)
        ident = random.randint(1, 1000)
        payload = b"NetLens Ping Sequence Data Payload"
        icmp_hdr = struct.pack("!BBHHH", icmp_type, 0, 0, ident, seq)
        
        # Calculate ICMP checksum
        cs = calculate_ipv4_checksum(icmp_hdr + payload)
        icmp = struct.pack("!BBHHH", icmp_type, 0, cs, ident, seq) + payload

        ip = build_ipv4_header(src_ip, dst_ip, 1, len(icmp))
        eth = build_ethernet_header(src_mac, dst_mac, 0x0800)
        return eth + ip + icmp

    def generate_arp_traffic(self) -> bytes:
        src_mac = random.choice(self.SAMPLE_MACS)
        src_ip = "192.168.1.10"
        target_ip = "192.168.1.1"
        arp = build_arp_packet(1, src_mac, src_ip, "00:00:00:00:00:00", target_ip)
        eth = build_ethernet_header(src_mac, "ff:ff:ff:ff:ff:ff", 0x0806)
        return eth + arp

    def generate_syn_packet(self) -> bytes:
        src_mac = random.choice(self.SAMPLE_MACS)
        dst_mac = "52:54:00:12:34:01"
        src_ip = random.choice(self.SAMPLE_IPS[:4])
        dst_ip = random.choice(self.SAMPLE_IPS[4:])
        src_port = random.randint(49152, 65535)
        dst_port = random.choice([80, 443, 22, 3306, 8080, 21])

        tcp = build_tcp_segment(src_port, dst_port, random.randint(100, 999999), 0, 0x002)  # SYN
        ip = build_ipv4_header(src_ip, dst_ip, 6, len(tcp))
        eth = build_ethernet_header(src_mac, dst_mac, 0x0800)
        return eth + ip + tcp

    def generate_port_scan_burst(self, attacker_ip: str = "192.168.1.200", target_ip: str = "192.168.1.50") -> List[bytes]:
        """Generates a quick sequence of SYN probes across sequential ports (Port Scan anomaly)."""
        packets = []
        src_mac = "AA:BB:CC:DD:EE:01"
        dst_mac = "52:54:00:12:34:01"

        for port in [21, 22, 23, 25, 80, 110, 135, 139, 443, 445, 1433, 3306, 3389, 8080]:
            src_port = random.randint(40000, 60000)
            tcp = build_tcp_segment(src_port, port, random.randint(1, 100000), 0, 0x002)  # SYN
            ip = build_ipv4_header(attacker_ip, target_ip, 6, len(tcp))
            eth = build_ethernet_header(src_mac, dst_mac, 0x0800)
            packets.append(eth + ip + tcp)
        return packets
