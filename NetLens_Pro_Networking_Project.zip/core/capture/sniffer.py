"""
Cross-Platform Live Raw Socket Sniffer
Handles native raw sockets (Windows SIO_RCVALL or Linux AF_PACKET) with seamless fallback to synthetic capture.
"""

import os
import socket
import threading
import time
from typing import Callable, Optional
from core.capture.generator import TrafficGenerator


class LiveSniffer:
    """Manages background packet capture from raw network interfaces or synthetic generators."""

    def __init__(self, packet_callback: Callable[[bytes, float], None]):
        self.packet_callback = packet_callback
        self.is_running = False
        self.is_synthetic = False
        self.capture_thread: Optional[threading.Thread] = None
        self.traffic_gen = TrafficGenerator()
        self.raw_socket: Optional[socket.socket] = None

    def start(self, use_synthetic: bool = False, interface_ip: Optional[str] = None):
        """Starts the capture thread."""
        if self.is_running:
            return

        self.is_running = True
        self.is_synthetic = use_synthetic

        if not use_synthetic:
            try:
                self._init_raw_socket(interface_ip)
            except Exception as e:
                # If raw sockets require root/admin or fail, fallback smoothly to synthetic mode
                print(f"[Sniffer] Raw socket unavailable ({e}). Falling back to high-fidelity synthetic traffic mode.")
                self.is_synthetic = True

        self.capture_thread = threading.Thread(target=self._capture_loop, daemon=True)
        self.capture_thread.start()

    def _init_raw_socket(self, interface_ip: Optional[str] = None):
        """Initializes raw socket based on Host OS."""
        if os.name == "nt":  # Windows
            host = interface_ip or socket.gethostbyname(socket.gethostname())
            self.raw_socket = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
            self.raw_socket.bind((host, 0))
            self.raw_socket.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            # Enable promiscuous mode on Windows
            self.raw_socket.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)
        else:  # Linux / Unix
            self.raw_socket = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))

        self.raw_socket.settimeout(0.5)

    def _capture_loop(self):
        """Continuously captures raw packets and invokes the callback."""
        while self.is_running:
            if self.is_synthetic:
                raw_bytes = self.traffic_gen.generate_random_packet()
                self.packet_callback(raw_bytes, time.time())
                time.sleep(random_interval := (0.05 + 0.15 * (time.time() % 1)))
            else:
                try:
                    raw_data, _ = self.raw_socket.recvfrom(65535)
                    self.packet_callback(raw_data, time.time())
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.is_running:
                        print(f"[Sniffer] Socket read error: {e}, switching to synthetic mode.")
                        self.is_synthetic = True

    def inject_port_scan_simulation(self):
        """Triggers an instantaneous port scan simulation burst."""
        packets = self.traffic_gen.generate_port_scan_burst()
        for pkt in packets:
            self.packet_callback(pkt, time.time())
            time.sleep(0.01)

    def stop(self):
        """Stops the capture process cleanly."""
        self.is_running = False
        if self.raw_socket:
            try:
                if os.name == "nt":
                    self.raw_socket.ioctl(socket.SIO_RCVALL, socket.RCVALL_OFF)
                self.raw_socket.close()
            except Exception:
                pass
            self.raw_socket = None
        if self.capture_thread and self.capture_thread.is_alive():
            self.capture_thread.join(timeout=1.0)
