"""
Deep Packet Inspection (DPI) Signature Matching Engine
Inspects application payloads for protocol signatures, credentials, and known exploit patterns.
"""

import re
from typing import List, Tuple, Optional


class DpiSignatureEngine:
    """Matches raw payloads against protocol and threat heuristics."""

    CLEARTEXT_PATTERNS = [
        (re.compile(r"password=([^\s&]+)", re.IGNORECASE), "Cleartext Password Parameter"),
        (re.compile(r"user(?:name)?=([^\s&]+)", re.IGNORECASE), "Cleartext Username Parameter"),
        (re.compile(r"Authorization:\s*Basic\s+([a-zA-Z0-9+/=]+)", re.IGNORECASE), "HTTP Basic Auth Header"),
        (re.compile(r"Bearer\s+([a-zA-Z0-9\._\-]+)", re.IGNORECASE), "Bearer Token in Payload"),
    ]

    EXPLOIT_PATTERNS = [
        (re.compile(r"(?:\b(?:union\s+select|select\s+.*\s+from|drop\s+table)\b)", re.IGNORECASE), "SQL Injection Attempt"),
        (re.compile(r"(?:<script>|javascript:|onerror=)", re.IGNORECASE), "Cross-Site Scripting (XSS) Pattern"),
        (re.compile(r"(?:\.\./\.\./|\.\.\\\.\.\\|etc/passwd|win\.ini)", re.IGNORECASE), "Directory Traversal Pattern"),
        (re.compile(r"(?:cmd\.exe|/bin/sh|/bin/bash|powershell)", re.IGNORECASE), "Remote Shell / Command Injection"),
    ]

    PROTOCOL_MAGIC = [
        (b"SSH-2.0", "SSH-2.0 Protocol"),
        (b"+PONG\r\n", "Redis RESP"),
        (b"*1\r\n$4\r\nPING\r\n", "Redis Command"),
        (b"\x00\x00\x00\x00\x04\x00\x00\x00", "MySQL Handshake Init"),
    ]

    def inspect_payload(self, payload_bytes: bytes, text_snippet: str) -> List[Tuple[str, str]]:
        """
        Scans payload and returns list of (category, matched_description).
        """
        findings = []

        # 1. Check Protocol Magics
        for magic, name in self.PROTOCOL_MAGIC:
            if magic in payload_bytes:
                findings.append(("DPI_PROTOCOL", f"Detected {name}"))

        # 2. Check for cleartext credentials / tokens
        if text_snippet:
            for pattern, desc in self.CLEARTEXT_PATTERNS:
                match = pattern.search(text_snippet)
                if match:
                    findings.append(("SECURITY_RISK", f"{desc}: {match.group(0)[:50]}"))

            # 3. Check for exploit indicators
            for pattern, desc in self.EXPLOIT_PATTERNS:
                if pattern.search(text_snippet):
                    findings.append(("EXPLOIT_PATTERN", desc))

        return findings
