"""
Network Threat & Behavioral Anomaly Detection Engine
Monitors sliding time windows for port scans, SYN floods, ARP poisoning, DNS tunnels, and DPI alerts.
"""

import collections
import math
import time
import uuid
from typing import Dict, List, Set, Tuple, Optional
from core.models import ParsedPacket, SecurityAnomaly, ThreatSeverity, ProtocolType
from core.security.signatures import DpiSignatureEngine


def calculate_entropy(text: str) -> float:
    """Calculates Shannon entropy of a string (useful for DNS tunnel / DGA detection)."""
    if not text:
        return 0.0
    freq = collections.Counter(text)
    length = len(text)
    return -sum((count / length) * math.log2(count / length) for count in freq.values())


class AnomalyDetector:
    """Real-time heuristic threat detector."""

    def __init__(self):
        self.dpi_engine = DpiSignatureEngine()
        self.anomalies: List[SecurityAnomaly] = []

        # Tracking state for port scan detection: src_ip -> deque of (timestamp, dst_port)
        self.port_scan_tracker: Dict[str, collections.deque] = collections.defaultdict(collections.deque)
        
        # Tracking state for SYN flood detection: src_ip -> deque of timestamps
        self.syn_tracker: Dict[str, collections.deque] = collections.defaultdict(collections.deque)

        # ARP Cache for poisoning detection: ip -> (mac, first_seen)
        self.arp_table: Dict[str, str] = {}

        # Cooldown dictionary to avoid duplicate alert spamming: alert_key -> last_alert_time
        self.alert_cooldowns: Dict[str, float] = {}

    def analyze_packet(self, packet: ParsedPacket) -> List[SecurityAnomaly]:
        """Analyzes packet and returns list of any triggered security alerts."""
        meta = packet.metadata
        now = meta.timestamp
        new_anomalies: List[SecurityAnomaly] = []

        # 1. Port Scan Detection (Vertical Scan on single target or Horizontal across subnets)
        if meta.src_ip and meta.dst_port is not None and "SYN" in (meta.tcp_flags or []):
            history = self.port_scan_tracker[meta.src_ip]
            history.append((now, meta.dst_port))
            # Clean entries older than 3 seconds
            while history and history[0][0] < now - 3.0:
                history.popleft()

            distinct_ports = {port for _, port in history}
            if len(distinct_ports) >= 6:
                alert_key = f"PORTSCAN_{meta.src_ip}"
                if self._check_cooldown(alert_key, now, cooldown=5.0):
                    anomaly = SecurityAnomaly(
                        id=str(uuid.uuid4())[:8],
                        timestamp=now,
                        title="Port Scan Activity Detected",
                        severity=ThreatSeverity.HIGH,
                        source_ip=meta.src_ip,
                        target_ip=meta.dst_ip,
                        description=f"Source host probed {len(distinct_ports)} distinct ports within 3 seconds.",
                        evidence_packet_ids=[meta.id],
                        remediation_tip="Inspect host for automated scanning tools or malware; apply firewall drop rules.",
                    )
                    new_anomalies.append(anomaly)
                    meta.is_anomaly = True
                    meta.anomaly_reason = anomaly.title

        # 2. SYN Flood Detection
        if meta.src_ip and "SYN" in (meta.tcp_flags or []) and "ACK" not in (meta.tcp_flags or []):
            syn_hist = self.syn_tracker[meta.src_ip]
            syn_hist.append(now)
            while syn_hist and syn_hist[0] < now - 2.0:
                syn_hist.popleft()

            if len(syn_hist) >= 20:
                alert_key = f"SYNFLOOD_{meta.src_ip}"
                if self._check_cooldown(alert_key, now, cooldown=5.0):
                    anomaly = SecurityAnomaly(
                        id=str(uuid.uuid4())[:8],
                        timestamp=now,
                        title="TCP SYN Flood Detected",
                        severity=ThreatSeverity.CRITICAL,
                        source_ip=meta.src_ip,
                        target_ip=meta.dst_ip,
                        description=f"Rapid burst of {len(syn_hist)} unacknowledged SYN packets within 2 seconds.",
                        evidence_packet_ids=[meta.id],
                        remediation_tip="Enable SYN cookies (tcp_syncookies) or rate-limit TCP SYN handshakes.",
                    )
                    new_anomalies.append(anomaly)
                    meta.is_anomaly = True
                    meta.anomaly_reason = anomaly.title

        # 3. ARP Spoofing / Poisoning Detection
        if meta.highest_protocol == "ARP":
            for layer in packet.layers:
                if layer.protocol == ProtocolType.ARP:
                    sender_ip = layer.fields.get("Sender IP")
                    sender_mac = layer.fields.get("Sender MAC")
                    if sender_ip and sender_mac:
                        if sender_ip in self.arp_table and self.arp_table[sender_ip] != sender_mac:
                            alert_key = f"ARPSPOOF_{sender_ip}"
                            if self._check_cooldown(alert_key, now, cooldown=10.0):
                                anomaly = SecurityAnomaly(
                                    id=str(uuid.uuid4())[:8],
                                    timestamp=now,
                                    title="Potential ARP Poisoning / MAC Conflict",
                                    severity=ThreatSeverity.HIGH,
                                    source_ip=sender_ip,
                                    target_ip=None,
                                    description=f"IP {sender_ip} changed MAC address from {self.arp_table[sender_ip]} to {sender_mac}.",
                                    evidence_packet_ids=[meta.id],
                                    remediation_tip="Verify DHCP snooping, dynamic ARP inspection (DAI), or static ARP tables.",
                                )
                                new_anomalies.append(anomaly)
                                meta.is_anomaly = True
                                meta.anomaly_reason = anomaly.title
                        self.arp_table[sender_ip] = sender_mac

        # 4. DNS Tunneling & DGA Detection
        for layer in packet.layers:
            if layer.protocol == ProtocolType.DNS:
                questions = layer.fields.get("Questions", [])
                for q in questions:
                    qname = q.get("name", "")
                    # Check for long high-entropy subdomains (indicative of base64/hex data exfiltration)
                    subdomain = qname.split(".")[0] if "." in qname else qname
                    if len(subdomain) > 25:
                        entropy = calculate_entropy(subdomain)
                        if entropy > 3.8:
                            alert_key = f"DNSTUNNEL_{qname}"
                            if self._check_cooldown(alert_key, now, cooldown=5.0):
                                anomaly = SecurityAnomaly(
                                    id=str(uuid.uuid4())[:8],
                                    timestamp=now,
                                    title="Suspicious High-Entropy DNS Query (Possible Exfiltration)",
                                    severity=ThreatSeverity.MEDIUM,
                                    source_ip=meta.src_ip or "Local",
                                    target_ip=meta.dst_ip,
                                    description=f"DNS query '{qname[:40]}...' exhibits high entropy ({entropy:.2f}) and length.",
                                    evidence_packet_ids=[meta.id],
                                    remediation_tip="Analyze host for DNS tunneling clients (e.g. iodine, dnscat2) and review domain reputation.",
                                )
                                new_anomalies.append(anomaly)
                                meta.is_anomaly = True
                                meta.anomaly_reason = anomaly.title

        # 5. DPI Payload Inspection
        payload_bytes = bytes.fromhex(packet.payload_hex) if packet.payload_hex else b""
        dpi_matches = self.dpi_engine.inspect_payload(payload_bytes, packet.payload_text)
        for cat, desc in dpi_matches:
            alert_key = f"DPI_{desc}"
            if self._check_cooldown(alert_key, now, cooldown=10.0):
                severity = ThreatSeverity.HIGH if cat == "EXPLOIT_PATTERN" else ThreatSeverity.MEDIUM
                anomaly = SecurityAnomaly(
                    id=str(uuid.uuid4())[:8],
                    timestamp=now,
                    title=f"DPI Alert: {desc}",
                    severity=severity,
                    source_ip=meta.src_ip or "N/A",
                    target_ip=meta.dst_ip or "N/A",
                    description=f"Deep Packet Inspection matched pattern: {desc}",
                    evidence_packet_ids=[meta.id],
                    remediation_tip="Enforce encrypted channels (HTTPS/TLS) and input validation WAF rules.",
                )
                new_anomalies.append(anomaly)
                meta.is_anomaly = True
                meta.anomaly_reason = anomaly.title

        self.anomalies.extend(new_anomalies)
        return new_anomalies

    def _check_cooldown(self, key: str, current_time: float, cooldown: float) -> bool:
        """Returns True if alert is permitted, updating timestamp."""
        last_time = self.alert_cooldowns.get(key, 0.0)
        if current_time - last_time >= cooldown:
            self.alert_cooldowns[key] = current_time
            return True
        return False

    def get_all_anomalies(self) -> List[SecurityAnomaly]:
        return sorted(self.anomalies, key=lambda a: a.timestamp, reverse=True)

    def clear(self):
        self.anomalies.clear()
        self.port_scan_tracker.clear()
        self.syn_tracker.clear()
        self.arp_table.clear()
        self.alert_cooldowns.clear()
