"""
Thread-Safe High Performance Circular Packet Storage & Indexer
Stores recent packets in memory with O(1) appending and fast filtered lookups.
"""

import threading
from typing import List, Optional, Dict
from core.models import ParsedPacket
from core.storage.filter import FilterEngine


class PacketRingBuffer:
    """Thread-safe circular ring buffer for parsed network packets."""

    def __init__(self, capacity: int = 50000):
        self.capacity = capacity
        self.lock = threading.Lock()
        self.packets: List[ParsedPacket] = []
        self.packet_map: Dict[int, ParsedPacket] = {}
        self.filter_engine = FilterEngine()
        self.packet_counter = 0

    def add_packet(self, packet: ParsedPacket) -> int:
        """Appends packet to ring buffer, maintaining fixed capacity."""
        with self.lock:
            self.packet_counter += 1
            if len(self.packets) >= self.capacity:
                oldest = self.packets.pop(0)
                self.packet_map.pop(oldest.metadata.id, None)

            self.packets.append(packet)
            self.packet_map[packet.metadata.id] = packet
            return self.packet_counter

    def get_packet_by_id(self, packet_id: int) -> Optional[ParsedPacket]:
        """Fetches full packet with layer hierarchy by unique ID."""
        with self.lock:
            return self.packet_map.get(packet_id)

    def query_packets(
        self,
        filter_expr: str = "",
        limit: int = 100,
        offset: int = 0,
        reverse: bool = True,
    ) -> List[ParsedPacket]:
        """Queries stored packets matching filter expression with pagination."""
        with self.lock:
            source_list = reversed(self.packets) if reverse else self.packets
            matching = []

            for pkt in source_list:
                if self.filter_engine.evaluate(pkt, filter_expr):
                    matching.append(pkt)

            return matching[offset : offset + limit]

    def get_count(self) -> int:
        with self.lock:
            return len(self.packets)

    def get_all_raw_bytes(self) -> List[bytes]:
        """Returns raw bytes of all buffered packets for PCAP export."""
        with self.lock:
            return [bytes.fromhex(p.raw_hex) for p in self.packets if p.raw_hex]

    def clear(self):
        """Clears all stored packets."""
        with self.lock:
            self.packets.clear()
            self.packet_map.clear()
