"""
Packet Filter Query Parser & Expression Evaluator
Evaluates BPF-like expressions (e.g. 'protocol == tcp and ip.src == "192.168.1.1" or port == 443').
"""

import re
from typing import Callable, Any, Optional
from core.models import ParsedPacket, ProtocolType


class FilterEngine:
    """Parses and executes queries against ParsedPacket objects."""

    def __init__(self):
        pass

    def evaluate(self, packet: ParsedPacket, query: str) -> bool:
        """
        Evaluates query string against packet.
        Returns True if packet matches filter query or query is empty.
        """
        query = query.strip()
        if not query:
            return True

        # Quick keyword match (e.g. "tcp", "dns", "http", "arp", "anomaly")
        lower_q = query.lower()
        if lower_q in ("tcp", "udp", "icmp", "arp", "dns", "http", "tls", "dhcp", "ipv4", "ipv6"):
            return lower_q in [l.protocol.value.lower() for l in packet.layers]

        if lower_q == "anomaly" or lower_q == "threat":
            return packet.metadata.is_anomaly

        # Expression-based parsing
        try:
            return self._eval_expression(packet, query)
        except Exception:
            # Fallback simple substring search across fields
            return self._fallback_search(packet, query)

    def _eval_expression(self, packet: ParsedPacket, query: str) -> bool:
        """Evaluates boolean clauses separated by 'and', 'or', '&&', '||'."""
        # Split on OR / || first
        or_clauses = re.split(r"\s+(?:or|\|\|)\s+", query, flags=re.IGNORECASE)
        if len(or_clauses) > 1:
            return any(self._eval_expression(packet, clause) for clause in or_clauses)

        # Split on AND / && next
        and_clauses = re.split(r"\s+(?:and|&&)\s+", query, flags=re.IGNORECASE)
        if len(and_clauses) > 1:
            return all(self._eval_expression(packet, clause) for clause in and_clauses)

        # Evaluate single clause (e.g., 'ip.src == "192.168.1.1"', 'tcp.port == 80', 'length > 100')
        clause = query.strip()
        
        # Check NOT
        if clause.lower().startswith("not ") or clause.startswith("!"):
            sub = clause[4:] if clause.lower().startswith("not ") else clause[1:]
            return not self._eval_expression(packet, sub)

        operators = ["==", "!=", ">=", "<=", ">", "<", "contains", "matches"]
        for op in operators:
            pattern = rf"^([\w\.]+)\s+{re.escape(op)}\s+(.+)$"
            match = re.match(pattern, clause, re.IGNORECASE)
            if match:
                field_name = match.group(1).strip().lower()
                val_str = match.group(2).strip().strip("\"'")
                return self._compare_field(packet, field_name, op.lower(), val_str)

        # Single word fallback
        return self._fallback_search(packet, query)

    def _get_field_value(self, packet: ParsedPacket, field_name: str) -> Any:
        meta = packet.metadata
        if field_name in ("proto", "protocol"):
            return meta.highest_protocol
        elif field_name in ("ip.src", "src.ip", "src_ip", "src"):
            return meta.src_ip
        elif field_name in ("ip.dst", "dst.ip", "dst_ip", "dst"):
            return meta.dst_ip
        elif field_name in ("port", "ports"):
            return [meta.src_port, meta.dst_port]
        elif field_name in ("tcp.port", "udp.port", "port.src", "src_port", "src.port"):
            return meta.src_port
        elif field_name in ("port.dst", "dst_port", "dst.port"):
            return meta.dst_port
        elif field_name in ("len", "length", "frame.len"):
            return meta.length
        elif field_name in ("info", "summary"):
            return meta.info
        elif field_name in ("payload", "data"):
            return packet.payload_text
        return None

    def _compare_field(self, packet: ParsedPacket, field_name: str, op: str, val_str: str) -> bool:
        actual = self._get_field_value(packet, field_name)
        if actual is None:
            return False

        if isinstance(actual, list):
            # If checking against port list [src_port, dst_port]
            if val_str.isdigit():
                val_num = int(val_str)
                if op == "==":
                    return val_num in actual
                elif op == "!=":
                    return val_num not in actual
            return False

        # Numeric comparison
        if isinstance(actual, (int, float)) and val_str.isdigit():
            val_num = int(val_str)
            if op == "==":
                return actual == val_num
            elif op == "!=":
                return actual != val_num
            elif op == ">":
                return actual > val_num
            elif op == "<":
                return actual < val_num
            elif op == ">=":
                return actual >= val_num
            elif op == "<=":
                return actual <= val_num

        # String comparison
        actual_str = str(actual).lower()
        target_str = val_str.lower()

        if op == "==":
            return actual_str == target_str
        elif op == "!=":
            return actual_str != target_str
        elif op == "contains":
            return target_str in actual_str
        elif op == "matches":
            return bool(re.search(target_str, actual_str))

        return False

    def _fallback_search(self, packet: ParsedPacket, search_term: str) -> bool:
        term = search_term.lower()
        meta = packet.metadata
        return (
            (term in (meta.src_ip or "").lower())
            or (term in (meta.dst_ip or "").lower())
            or (term in meta.highest_protocol.lower())
            or (term in meta.info.lower())
            or (term in packet.payload_text.lower())
        )
