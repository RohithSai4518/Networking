"""
Real-Time Telemetry and Network Metrics Engine
Calculates sliding-window throughput, packet rates, top talkers, and protocol breakdowns.
"""

import collections
import time
from typing import Dict, Deque, Tuple
from core.models import ParsedPacket, NetworkStats


class MetricsEngine:
    """Aggregates telemetry statistics and sliding-window bandwidth."""

    def __init__(self, window_seconds: float = 2.0):
        self.window_seconds = window_seconds
        self.total_packets = 0
        self.total_bytes = 0
        self.protocol_counts: Dict[str, int] = collections.defaultdict(int)
        self.source_counts: Dict[str, int] = collections.defaultdict(int)
        self.dest_counts: Dict[str, int] = collections.defaultdict(int)
        # History queue of (timestamp, byte_length)
        self.history: Deque[Tuple[float, int]] = collections.deque()

    def record_packet(self, packet: ParsedPacket):
        """Records a new packet into metrics accumulator."""
        meta = packet.metadata
        now = meta.timestamp
        self.total_packets += 1
        self.total_bytes += meta.length

        self.protocol_counts[meta.highest_protocol] += 1
        if meta.src_ip:
            self.source_counts[meta.src_ip] += 1
        if meta.dst_ip:
            self.dest_counts[meta.dst_ip] += 1

        self.history.append((now, meta.length))
        self._prune_old_records(now)

    def _prune_old_records(self, current_time: float):
        """Discards data points older than the sliding window."""
        cutoff = current_time - self.window_seconds
        while self.history and self.history[0][0] < cutoff:
            self.history.popleft()

    def get_stats(self, active_flows: int = 0, anomaly_count: int = 0) -> NetworkStats:
        """Returns current snapshot of computed network metrics."""
        now = time.time()
        self._prune_old_records(now)

        window_bytes = sum(b for _, b in self.history)
        window_packets = len(self.history)
        duration = max(0.2, self.window_seconds)

        pps = window_packets / duration
        bps = window_bytes / duration

        # Top 5 sources and destinations
        top_src = dict(sorted(self.source_counts.items(), key=lambda x: x[1], reverse=True)[:5])
        top_dst = dict(sorted(self.dest_counts.items(), key=lambda x: x[1], reverse=True)[:5])

        return NetworkStats(
            total_packets=self.total_packets,
            total_bytes=self.total_bytes,
            packets_per_second=pps,
            bytes_per_second=bps,
            protocol_distribution=dict(self.protocol_counts),
            top_sources=top_src,
            top_destinations=top_dst,
            active_flow_count=active_flows,
            anomaly_count=anomaly_count,
        )

    def clear(self):
        """Resets all metrics."""
        self.total_packets = 0
        self.total_bytes = 0
        self.protocol_counts.clear()
        self.source_counts.clear()
        self.dest_counts.clear()
        self.history.clear()
