"""
TCP Stream Sequence Tracking and Payload Reassembly Engine
Handles out-of-order segments, duplicate packets, and continuous data stream reconstruction.
"""

from typing import Dict, List, Tuple


class TcpStreamReassembler:
    """Reassembles ordered payload byte streams for a single directional TCP flow."""

    def __init__(self, initial_seq: int = 0):
        self.initial_seq = initial_seq
        self.next_expected_seq = initial_seq
        # Dictionary of sequence_number -> payload_bytes
        self.buffered_segments: Dict[int, bytes] = {}
        self.reassembled_stream = bytearray()
        self.is_syn_seen = bool(initial_seq > 0)
        self.is_fin_seen = False

    def add_segment(self, seq: int, payload: bytes, is_syn: bool = False, is_fin: bool = False):
        """Processes a TCP segment and appends ordered contiguous payload data."""
        if is_syn:
            self.initial_seq = seq
            self.next_expected_seq = seq + 1
            self.is_syn_seen = True
            return

        if not payload:
            if is_fin:
                self.is_fin_seen = True
            return

        if not self.is_syn_seen:
            # If capture started mid-stream without prior SYN
            self.initial_seq = seq
            self.next_expected_seq = seq
            self.is_syn_seen = True

        # If stream hasn't produced data yet and an earlier sequence arrives
        if len(self.reassembled_stream) == 0 and seq < self.next_expected_seq:
            self.next_expected_seq = seq

        # Store in buffer
        self.buffered_segments[seq] = payload
        self._flush_contiguous()

        if is_fin:
            self.is_fin_seen = True

    def _flush_contiguous(self):
        """Flushes contiguous segments in order from the buffer into the reassembled stream."""
        while self.next_expected_seq in self.buffered_segments:
            seg = self.buffered_segments.pop(self.next_expected_seq)
            self.reassembled_stream.extend(seg)
            self.next_expected_seq += len(seg)

    def get_text_preview(self, max_len: int = 4096) -> str:
        """Returns human-readable ASCII/UTF-8 representation of the reassembled stream."""
        return self.reassembled_stream[:max_len].decode("utf-8", errors="replace")

    def get_raw_bytes(self) -> bytes:
        return bytes(self.reassembled_stream)
