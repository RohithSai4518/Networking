"""
Network Flow & Conversation Tracker Engine
Tracks active bidirectional flows based on IP 5-tuple (src_ip, dst_ip, src_port, dst_port, protocol).
"""

import time
from typing import Dict, List, Optional
from core.models import ParsedPacket, FlowKey, NetworkFlow, ProtocolType
from core.flows.reassembly import TcpStreamReassembler


class FlowTracker:
    """Maintains active network conversations and performs TCP payload stream tracking."""

    def __init__(self, flow_timeout: float = 60.0):
        self.flow_timeout = flow_timeout
        self.flows: Dict[str, NetworkFlow] = {}
        self.tcp_streams: Dict[str, TcpStreamReassembler] = {}

    def process_packet(self, packet: ParsedPacket) -> Optional[NetworkFlow]:
        """Updates or registers a network flow for the incoming packet."""
        meta = packet.metadata
        if not meta.src_ip or not meta.dst_ip or meta.src_port is None or meta.dst_port is None:
            return None

        # Create directional key
        raw_key = FlowKey(
            src_ip=meta.src_ip,
            dst_ip=meta.dst_ip,
            src_port=meta.src_port,
            dst_port=meta.dst_port,
            protocol=meta.highest_protocol,
        )

        canonical_key = raw_key.canonical()
        flow_id = canonical_key.to_string()
        is_forward = (raw_key.src_ip == canonical_key.src_ip and raw_key.src_port == canonical_key.src_port)

        now = meta.timestamp

        if flow_id not in self.flows:
            flow = NetworkFlow(
                key=canonical_key,
                start_time=now,
                last_seen=now,
                application=meta.highest_protocol,
            )
            self.flows[flow_id] = flow
        else:
            flow = self.flows[flow_id]
            flow.last_seen = now
            if flow.application in ("TCP", "UDP", "IPv4", "IPv6") and meta.highest_protocol not in ("TCP", "UDP", "IPv4", "IPv6"):
                flow.application = meta.highest_protocol

        # Update counters
        if is_forward:
            flow.total_packets_forward += 1
            flow.total_bytes_forward += meta.length
        else:
            flow.total_packets_reverse += 1
            flow.total_bytes_reverse += meta.length

        # TCP Stream Reassembly & State Machine
        if "TCP" in [layer.layer_name for layer in packet.layers]:
            tcp_layer = next((l for l in packet.layers if l.protocol == ProtocolType.TCP), None)
            if tcp_layer:
                flags = tcp_layer.fields.get("Flags", {})
                is_syn = flags.get("SYN", False)
                is_fin = flags.get("FIN", False)
                is_rst = flags.get("RST", False)
                seq = tcp_layer.fields.get("Sequence Number", 0)

                if is_rst:
                    flow.state = "RESET"
                elif is_fin:
                    flow.state = "CLOSED"
                elif is_syn and flags.get("ACK", False):
                    flow.state = "ESTABLISHED"
                elif is_syn:
                    flow.state = "SYN_SENT"

                stream_key = f"{flow_id}_{'F' if is_forward else 'R'}"
                if stream_key not in self.tcp_streams:
                    self.tcp_streams[stream_key] = TcpStreamReassembler(initial_seq=seq)

                payload_bytes = bytes.fromhex(packet.payload_hex) if packet.payload_hex else b""
                self.tcp_streams[stream_key].add_segment(seq, payload_bytes, is_syn=is_syn, is_fin=is_fin)

        return flow

    def get_all_flows(self) -> List[NetworkFlow]:
        """Returns list of all active network flows sorted by recency."""
        return sorted(self.flows.values(), key=lambda f: f.last_seen, reverse=True)

    def get_flow_reassembled_data(self, flow_key_str: str) -> Dict[str, str]:
        """Returns reconstructed forward and reverse payload text streams for a conversation."""
        f_key = f"{flow_key_str}_F"
        r_key = f"{flow_key_str}_R"

        f_stream = self.tcp_streams.get(f_key)
        r_stream = self.tcp_streams.get(r_key)

        return {
            "client_to_server": f_stream.get_text_preview() if f_stream else "",
            "server_to_client": r_stream.get_text_preview() if r_stream else "",
        }

    def cleanup_stale_flows(self):
        """Purges old inactive flows that exceeded the timeout."""
        cutoff = time.time() - self.flow_timeout
        stale_keys = [k for k, f in self.flows.items() if f.last_seen < cutoff]
        for k in stale_keys:
            self.flows.pop(k, None)
            self.tcp_streams.pop(f"{k}_F", None)
            self.tcp_streams.pop(f"{k}_R", None)

    def clear(self):
        """Clears all stored flows."""
        self.flows.clear()
        self.tcp_streams.clear()
