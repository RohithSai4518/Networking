"""
Address Resolution Protocol (ARP) Decoder (RFC 826)
Decodes ARP hardware type, protocol type, operations (Request, Reply), and IP/MAC pairings.
"""

import socket
import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType
from core.protocols.ethernet import format_mac


ARP_OPERATIONS = {
    1: "ARP Request (1)",
    2: "ARP Reply (2)",
    3: "RARP Request (3)",
    4: "RARP Reply (4)",
}


def decode_arp(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int]:
    """
    Decode an ARP payload.
    Returns: (LayerInfo, next_offset)
    """
    if len(data) - offset < 28:
        return None, offset

    # Standard Ethernet IPv4 ARP is 28 bytes
    htype, ptype, hlen, plen, oper = struct.unpack("!HHBBH", data[offset : offset + 8])
    
    if hlen != 6 or plen != 4:
        # Non-standard hardware/protocol length
        raw_header = data[offset : offset + 8 + (hlen * 2) + (plen * 2)]
        return LayerInfo(
            layer_name="ARP (Non-Standard)",
            protocol=ProtocolType.ARP,
            offset=offset,
            length=len(raw_header),
            fields={"Operation": ARP_OPERATIONS.get(oper, f"Opcode {oper}")},
            raw_header_hex=raw_header.hex(),
        ), offset + len(raw_header)

    sha = format_mac(data[offset + 8 : offset + 14])
    spa = socket.inet_ntoa(data[offset + 14 : offset + 18])
    tha = format_mac(data[offset + 18 : offset + 24])
    tpa = socket.inet_ntoa(data[offset + 24 : offset + 28])

    header_len = 28
    raw_header_hex = data[offset : offset + header_len].hex()

    oper_str = ARP_OPERATIONS.get(oper, f"Opcode {oper}")

    fields: Dict[str, Any] = {
        "Hardware Type": f"0x{htype:04x} ({'Ethernet' if htype == 1 else 'Other'})",
        "Protocol Type": f"0x{ptype:04x} ({'IPv4' if ptype == 0x0800 else 'Other'})",
        "Hardware Size": hlen,
        "Protocol Size": plen,
        "Opcode": oper_str,
        "Sender MAC": sha,
        "Sender IP": spa,
        "Target MAC": tha,
        "Target IP": tpa,
    }

    info_desc = f"Who has {tpa}? Tell {spa}" if oper == 1 else f"{spa} is at {sha}"
    fields["Summary"] = info_desc

    layer = LayerInfo(
        layer_name="Address Resolution Protocol",
        protocol=ProtocolType.ARP,
        offset=offset,
        length=header_len,
        fields=fields,
        raw_header_hex=raw_header_hex,
    )

    return layer, offset + header_len
