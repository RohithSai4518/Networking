"""
Internet Protocol Version 6 (IPv6) Decoder (RFC 8200)
Decodes IPv6 fixed 40-byte base header, Traffic Class, Flow Label, and Next Header chain.
"""

import socket
import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType
from core.protocols.ipv4 import IP_PROTOCOLS


def decode_ipv6(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int, int, int]:
    """
    Decode an IPv6 header.
    Returns: (LayerInfo, next_protocol_number, payload_length, payload_offset)
    """
    if len(data) - offset < 40:
        return None, 0, 0, offset

    header_bytes = data[offset : offset + 40]
    first_dword, payload_len, next_header, hop_limit = struct.unpack("!IHBB", header_bytes[:8])

    version = (first_dword >> 28) & 0x0F
    if version != 6:
        return None, 0, 0, offset

    traffic_class = (first_dword >> 20) & 0xFF
    flow_label = first_dword & 0xFFFFF

    src_ip = socket.inet_ntop(socket.AF_INET6, header_bytes[8:24])
    dst_ip = socket.inet_ntop(socket.AF_INET6, header_bytes[24:40])

    fields: Dict[str, Any] = {
        "Version": version,
        "Traffic Class": f"0x{traffic_class:02x}",
        "Flow Label": f"0x{flow_label:05x}",
        "Payload Length": f"{payload_len} bytes",
        "Next Header": f"{next_header} ({IP_PROTOCOLS.get(next_header, 'Extension Header / Protocol')})",
        "Hop Limit": hop_limit,
        "Source IP": src_ip,
        "Destination IP": dst_ip,
    }

    layer = LayerInfo(
        layer_name="Internet Protocol Version 6",
        protocol=ProtocolType.IPV6,
        offset=offset,
        length=40,
        fields=fields,
        raw_header_hex=header_bytes.hex(),
    )

    payload_offset = offset + 40
    return layer, next_header, payload_len, payload_offset
