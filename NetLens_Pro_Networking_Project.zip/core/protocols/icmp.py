"""
Internet Control Message Protocol (ICMPv4 & ICMPv6) Decoder
Decodes ICMP Types, Codes, Echo Identifiers, Sequence numbers, and error payloads.
"""

import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType


ICMP_TYPE_MAP = {
    0: "Echo Reply",
    3: "Destination Unreachable",
    4: "Source Quench",
    5: "Redirect",
    8: "Echo Request",
    9: "Router Advertisement",
    10: "Router Solicitation",
    11: "Time Exceeded",
    12: "Parameter Problem",
    13: "Timestamp Request",
    14: "Timestamp Reply",
}

ICMP_UNREACHABLE_CODES = {
    0: "Net Unreachable",
    1: "Host Unreachable",
    2: "Protocol Unreachable",
    3: "Port Unreachable",
    4: "Fragmentation Needed and DF set",
    5: "Source Route Failed",
}


def decode_icmp(data: bytes, offset: int = 0, is_ipv6: bool = False) -> Tuple[Optional[LayerInfo], int]:
    """
    Decode an ICMP header.
    Returns: (LayerInfo, payload_offset)
    """
    if len(data) - offset < 8:
        return None, offset

    icmp_type, code, checksum = struct.unpack("!BBH", data[offset : offset + 4])
    header_bytes = data[offset : offset + 8]
    raw_header_hex = header_bytes.hex()

    type_name = ICMP_TYPE_MAP.get(icmp_type, f"Type {icmp_type}")
    code_desc = f"Code {code}"
    if icmp_type == 3:
        code_desc = ICMP_UNREACHABLE_CODES.get(code, code_desc)

    fields: Dict[str, Any] = {
        "Type": f"{icmp_type} ({type_name})",
        "Code": f"{code} ({code_desc})",
        "Checksum": f"0x{checksum:04x}",
    }

    # If Echo Request (8) or Echo Reply (0)
    if icmp_type in (0, 8):
        ident, seq = struct.unpack("!HH", data[offset + 4 : offset + 8])
        fields["Identifier (BE)"] = ident
        fields["Sequence Number (BE)"] = seq
        fields["Summary"] = f"{type_name} id={ident} seq={seq}"
    else:
        rest_of_header = data[offset + 4 : offset + 8].hex()
        fields["Header Data"] = f"0x{rest_of_header}"
        fields["Summary"] = f"{type_name} ({code_desc})"

    protocol_type = ProtocolType.ICMPV6 if is_ipv6 else ProtocolType.ICMP
    layer = LayerInfo(
        layer_name="ICMPv6" if is_ipv6 else "ICMP",
        protocol=protocol_type,
        offset=offset,
        length=8,
        fields=fields,
        raw_header_hex=raw_header_hex,
    )

    return layer, offset + 8
