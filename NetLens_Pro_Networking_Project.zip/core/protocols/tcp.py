"""
Transmission Control Protocol (TCP) Decoder (RFC 793, RFC 7323)
Decodes TCP headers, Flags (SYN, ACK, FIN, RST, PSH, URG, ECE, CWR),
Window size, Checksum, Urgent pointer, and TCP Options (MSS, Window Scale, SACK, Timestamps).
"""

import struct
from typing import Tuple, Dict, Any, List, Optional
from core.models import LayerInfo, ProtocolType


def decode_tcp_options(options_bytes: bytes) -> List[Dict[str, Any]]:
    """Decodes variable-length TCP Options bytes into structured list."""
    options = []
    idx = 0
    length = len(options_bytes)

    while idx < length:
        kind = options_bytes[idx]
        if kind == 0:  # End of Option List (EOL)
            options.append({"kind": 0, "name": "EOL"})
            break
        elif kind == 1:  # No Operation (NOP)
            options.append({"kind": 1, "name": "NOP"})
            idx += 1
            continue

        if idx + 1 >= length:
            break

        opt_len = options_bytes[idx + 1]
        if opt_len < 2 or idx + opt_len > length:
            break

        opt_data = options_bytes[idx + 2 : idx + opt_len]

        if kind == 2 and opt_len == 4:  # Maximum Segment Size (MSS)
            mss = struct.unpack("!H", opt_data)[0]
            options.append({"kind": 2, "name": "MSS", "value": mss})
        elif kind == 3 and opt_len == 3:  # Window Scale
            wscale = opt_data[0]
            options.append({"kind": 3, "name": "Window Scale", "value": wscale, "multiplier": 1 << wscale})
        elif kind == 4 and opt_len == 2:  # SACK Permitted
            options.append({"kind": 4, "name": "SACK Permitted"})
        elif kind == 8 and opt_len == 10:  # Timestamps
            ts_val, ts_ecr = struct.unpack("!II", opt_data)
            options.append({"kind": 8, "name": "Timestamps", "tsval": ts_val, "tsecr": ts_ecr})
        else:
            options.append({"kind": kind, "name": f"Option {kind}", "raw_hex": opt_data.hex()})

        idx += opt_len

    return options


def decode_tcp(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int, int, List[str], int]:
    """
    Decode a TCP header.
    Returns: (LayerInfo, src_port, dst_port, active_flags_list, payload_offset)
    """
    if len(data) - offset < 20:
        return None, 0, 0, [], offset

    src_port, dst_port, seq_num, ack_num, offset_flags, window, checksum, urg_ptr = struct.unpack(
        "!HHIIHHHH", data[offset : offset + 20]
    )

    data_offset = ((offset_flags >> 12) & 0x0F) * 4
    if data_offset < 20 or len(data) - offset < data_offset:
        return None, 0, 0, [], offset

    flags_raw = offset_flags & 0x01FF

    flag_defs = [
        (0x0100, "NS"),
        (0x0080, "CWR"),
        (0x0040, "ECE"),
        (0x0020, "URG"),
        (0x0010, "ACK"),
        (0x0008, "PSH"),
        (0x0004, "RST"),
        (0x0002, "SYN"),
        (0x0001, "FIN"),
    ]

    active_flags = [name for mask, name in flag_defs if flags_raw & mask]
    flags_summary = "[" + ",".join(active_flags) + "]" if active_flags else "[None]"

    header_bytes = data[offset : offset + data_offset]
    raw_header_hex = header_bytes.hex()

    fields: Dict[str, Any] = {
        "Source Port": src_port,
        "Destination Port": dst_port,
        "Sequence Number": seq_num,
        "Acknowledgment Number": ack_num,
        "Header Length": f"{data_offset} bytes",
        "Flags": {
            "Raw": f"0x{flags_raw:03x}",
            "Summary": flags_summary,
            "SYN": bool(flags_raw & 0x0002),
            "ACK": bool(flags_raw & 0x0010),
            "FIN": bool(flags_raw & 0x0001),
            "RST": bool(flags_raw & 0x0004),
            "PSH": bool(flags_raw & 0x0008),
            "URG": bool(flags_raw & 0x0020),
        },
        "Window Size": window,
        "Checksum": f"0x{checksum:04x}",
        "Urgent Pointer": urg_ptr,
    }

    if data_offset > 20:
        options_bytes = data[offset + 20 : offset + data_offset]
        fields["TCP Options"] = decode_tcp_options(options_bytes)

    layer = LayerInfo(
        layer_name="Transmission Control Protocol",
        protocol=ProtocolType.TCP,
        offset=offset,
        length=data_offset,
        fields=fields,
        raw_header_hex=raw_header_hex,
    )

    payload_offset = offset + data_offset
    return layer, src_port, dst_port, active_flags, payload_offset
