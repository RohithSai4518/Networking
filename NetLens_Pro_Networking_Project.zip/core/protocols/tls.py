"""
Transport Layer Security (TLS) Decoder (RFC 5246, RFC 8446)
Decodes TLS Record Layer Content Types, Handshake messages, and extracts SNI (Server Name Indication).
"""

import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType


CONTENT_TYPES = {
    20: "ChangeCipherSpec",
    21: "Alert",
    22: "Handshake",
    23: "ApplicationData",
    24: "Heartbeat",
}

TLS_VERSIONS = {
    0x0300: "SSL 3.0",
    0x0301: "TLS 1.0",
    0x0302: "TLS 1.1",
    0x0303: "TLS 1.2",
    0x0304: "TLS 1.3",
}

HANDSHAKE_TYPES = {
    1: "ClientHello",
    2: "ServerHello",
    11: "Certificate",
    12: "ServerKeyExchange",
    13: "CertificateRequest",
    14: "ServerHelloDone",
    15: "CertificateVerify",
    16: "ClientKeyExchange",
    20: "Finished",
}


def extract_sni_from_client_hello(data: bytes, handshake_offset: int) -> Optional[str]:
    """Extracts Server Name Indication (SNI) hostname from ClientHello extensions."""
    try:
        # Handshake: Type(1), Length(3), Version(2), Random(32), SessionID_Len(1)
        curr = handshake_offset + 4  # skip type + length
        curr += 2 + 32  # skip version + random
        if curr >= len(data):
            return None
        sess_id_len = data[curr]
        curr += 1 + sess_id_len

        if curr + 2 > len(data):
            return None
        cipher_suites_len = struct.unpack("!H", data[curr : curr + 2])[0]
        curr += 2 + cipher_suites_len

        if curr + 1 > len(data):
            return None
        comp_methods_len = data[curr]
        curr += 1 + comp_methods_len

        if curr + 2 > len(data):
            return None
        extensions_len = struct.unpack("!H", data[curr : curr + 2])[0]
        curr += 2
        ext_end = min(len(data), curr + extensions_len)

        while curr + 4 <= ext_end:
            ext_type, ext_len = struct.unpack("!HH", data[curr : curr + 4])
            curr += 4
            if ext_type == 0:  # Server Name Indication (SNI)
                # server_name_list_length (2), name_type (1), name_length (2), hostname
                if curr + 5 <= ext_end:
                    _sni_list_len = struct.unpack("!H", data[curr : curr + 2])[0]
                    name_type = data[curr + 2]
                    name_len = struct.unpack("!H", data[curr + 3 : curr + 5])[0]
                    if name_type == 0 and curr + 5 + name_len <= ext_end:
                        return data[curr + 5 : curr + 5 + name_len].decode("utf-8", errors="replace")
            curr += ext_len
    except Exception:
        return None
    return None


def decode_tls(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int]:
    """
    Decode a TLS record layer header.
    Returns: (LayerInfo, next_offset)
    """
    if len(data) - offset < 5:
        return None, offset

    content_type, version_code, length = struct.unpack("!BHH", data[offset : offset + 5])

    # Validate valid TLS content type and version
    if content_type not in CONTENT_TYPES or version_code not in TLS_VERSIONS:
        return None, offset

    content_type_str = CONTENT_TYPES.get(content_type, f"Type {content_type}")
    version_str = TLS_VERSIONS.get(version_code, f"0x{version_code:04x}")

    fields: Dict[str, Any] = {
        "Content Type": f"{content_type_str} ({content_type})",
        "Version": version_str,
        "Length": f"{length} bytes",
    }

    summary = f"TLS Record Layer: {content_type_str} (v{version_str})"

    # If Handshake Record
    if content_type == 22 and len(data) - offset >= 9:
        handshake_type = data[offset + 5]
        hs_name = HANDSHAKE_TYPES.get(handshake_type, f"Handshake Type {handshake_type}")
        fields["Handshake Type"] = hs_name
        summary = f"TLS Handshake: {hs_name}"

        if handshake_type == 1:  # ClientHello
            sni = extract_sni_from_client_hello(data, offset + 5)
            if sni:
                fields["Server Name (SNI)"] = sni
                summary += f" (SNI={sni})"

    fields["Summary"] = summary
    total_record_len = 5 + length
    raw_hex = data[offset : min(len(data), offset + total_record_len)].hex()

    layer = LayerInfo(
        layer_name="Transport Layer Security",
        protocol=ProtocolType.TLS,
        offset=offset,
        length=min(len(data) - offset, total_record_len),
        fields=fields,
        raw_header_hex=raw_hex,
    )

    return layer, offset + min(len(data) - offset, total_record_len)
