"""
Internet Protocol Version 4 (IPv4) Decoder (RFC 791)
Decodes IPv4 header fields, fragmentation, TOS/DSCP/ECN, TTL, protocol numbers, and IP options.
"""

import socket
import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType


IP_PROTOCOLS = {
    1: "ICMP",
    2: "IGMP",
    6: "TCP",
    17: "UDP",
    41: "IPv6 encapsulation",
    47: "GRE",
    50: "ESP",
    51: "AH",
    89: "OSPF",
}


def calculate_ipv4_checksum(header_bytes: bytes) -> int:
    """Computes standard Internet Checksum (16-bit 1's complement sum of 1's complements)."""
    if len(header_bytes) % 2 != 0:
        header_bytes += b"\x00"
    
    checksum = 0
    for i in range(0, len(header_bytes), 2):
        word = (header_bytes[i] << 8) + header_bytes[i + 1]
        checksum += word
        checksum = (checksum & 0xFFFF) + (checksum >> 16)
    
    return ~checksum & 0xFFFF


def decode_ipv4(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int, int, int]:
    """
    Decode an IPv4 header.
    Returns: (LayerInfo, next_protocol_number, total_length, payload_offset)
    """
    if len(data) - offset < 20:
        return None, 0, 0, offset

    first_byte = data[offset]
    version = (first_byte >> 4) & 0x0F
    ihl = (first_byte & 0x0F) * 4

    if version != 4 or ihl < 20 or len(data) - offset < ihl:
        return None, 0, 0, offset

    tos = data[offset + 1]
    dscp = (tos >> 2) & 0x3F
    ecn = tos & 0x03

    total_len, ident, flags_frag, ttl, proto, checksum = struct.unpack(
        "!HHHBBH", data[offset + 2 : offset + 12]
    )

    df_flag = bool(flags_frag & 0x4000)
    mf_flag = bool(flags_frag & 0x2000)
    frag_offset = (flags_frag & 0x1FFF) * 8

    src_ip = socket.inet_ntoa(data[offset + 12 : offset + 16])
    dst_ip = socket.inet_ntoa(data[offset + 16 : offset + 20])

    header_bytes = data[offset : offset + ihl]
    raw_header_hex = header_bytes.hex()

    # Validate header checksum (zeroing out checksum field for verification)
    test_header = bytearray(header_bytes)
    test_header[10] = 0
    test_header[11] = 0
    expected_checksum = calculate_ipv4_checksum(bytes(test_header))
    checksum_valid = (expected_checksum == checksum)

    fields: Dict[str, Any] = {
        "Version": version,
        "Header Length": f"{ihl} bytes",
        "Differentiated Services Field": f"0x{tos:02x} (DSCP: {dscp}, ECN: {ecn})",
        "Total Length": f"{total_len} bytes",
        "Identification": f"0x{ident:04x} ({ident})",
        "Flags": {
            "Don't Fragment (DF)": df_flag,
            "More Fragments (MF)": mf_flag,
            "Raw": f"0x{(flags_frag >> 13):x}",
        },
        "Fragment Offset": frag_offset,
        "Time to Live (TTL)": ttl,
        "Protocol": f"{proto} ({IP_PROTOCOLS.get(proto, 'Unknown')})",
        "Header Checksum": f"0x{checksum:04x} ({'Valid' if checksum_valid else 'Invalid'})",
        "Source IP": src_ip,
        "Destination IP": dst_ip,
    }

    if ihl > 20:
        fields["Options Hex"] = data[offset + 20 : offset + ihl].hex()

    layer = LayerInfo(
        layer_name="Internet Protocol Version 4",
        protocol=ProtocolType.IPV4,
        offset=offset,
        length=ihl,
        fields=fields,
        raw_header_hex=raw_header_hex,
    )

    payload_offset = offset + ihl
    return layer, proto, total_len, payload_offset
