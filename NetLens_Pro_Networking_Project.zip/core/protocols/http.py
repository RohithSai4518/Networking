"""
Hypertext Transfer Protocol (HTTP/1.x) Decoder
Parses HTTP Requests (GET, POST, PUT, DELETE, etc.) and Responses (200 OK, 404 Not Found, etc.),
headers, content types, and body excerpts.
"""

from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType


HTTP_METHODS = {"GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS", "PATCH", "TRACE", "CONNECT"}


def decode_http(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int]:
    """
    Decode an HTTP request or response header from payload bytes.
    Returns: (LayerInfo, next_offset)
    """
    payload = data[offset:]
    if len(payload) < 4:
        return None, offset

    # Check for HTTP Header boundary
    header_end = payload.find(b"\r\n\r\n")
    if header_end == -1:
        header_end = payload.find(b"\n\n")
        delimiter_len = 2 if header_end != -1 else 0
    else:
        delimiter_len = 4

    if header_end == -1:
        # Check if start line looks like HTTP request or response anyway
        lines = payload.split(b"\n", 1)
        if not lines:
            return None, offset
        first_line = lines[0].strip().decode("latin1", errors="replace")
        parts = first_line.split()
        if not (len(parts) >= 2 and (parts[0].upper() in HTTP_METHODS or parts[0].startswith("HTTP/"))):
            return None, offset
        raw_headers_bytes = payload
        body_bytes = b""
        total_len = len(payload)
    else:
        raw_headers_bytes = payload[:header_end]
        body_bytes = payload[header_end + delimiter_len :]
        total_len = len(payload)

    text_headers = raw_headers_bytes.decode("latin1", errors="replace")
    lines = text_headers.splitlines()
    if not lines:
        return None, offset

    start_line = lines[0].strip()
    parts = start_line.split()
    if len(parts) < 2:
        return None, offset

    is_request = False
    is_response = False
    fields: Dict[str, Any] = {}

    if parts[0].upper() in HTTP_METHODS:
        is_request = True
        fields["Type"] = "HTTP Request"
        fields["Method"] = parts[0].upper()
        fields["URI"] = parts[1] if len(parts) > 1 else "/"
        fields["Version"] = parts[2] if len(parts) > 2 else "HTTP/1.1"
        fields["Summary"] = f"{fields['Method']} {fields['URI']} {fields['Version']}"
    elif parts[0].upper().startswith("HTTP/"):
        is_response = True
        fields["Type"] = "HTTP Response"
        fields["Version"] = parts[0]
        fields["Status Code"] = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 200
        fields["Status Phrase"] = " ".join(parts[2:]) if len(parts) > 2 else "OK"
        fields["Summary"] = f"{fields['Version']} {fields['Status Code']} {fields['Status Phrase']}"
    else:
        return None, offset

    headers_dict: Dict[str, str] = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers_dict[k.strip()] = v.strip()

    fields["Headers"] = headers_dict

    if "Host" in headers_dict:
        fields["Host"] = headers_dict["Host"]
    if "Content-Type" in headers_dict:
        fields["Content-Type"] = headers_dict["Content-Type"]
    if "Content-Length" in headers_dict:
        fields["Content-Length"] = headers_dict["Content-Length"]
    if "User-Agent" in headers_dict:
        fields["User-Agent"] = headers_dict["User-Agent"]

    if body_bytes:
        fields["Body Length"] = len(body_bytes)
        # Include snippet of body if textual
        body_snippet = body_bytes[:256].decode("utf-8", errors="replace")
        fields["Body Preview"] = body_snippet

    layer = LayerInfo(
        layer_name="Hypertext Transfer Protocol",
        protocol=ProtocolType.HTTP,
        offset=offset,
        length=total_len,
        fields=fields,
        raw_header_hex=payload.hex(),
    )

    return layer, offset + total_len
