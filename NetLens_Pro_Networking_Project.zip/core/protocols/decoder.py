"""
Master Packet Decoder Engine
Orchestrates layer-by-layer recursive decoding of arbitrary network frames.
"""

from typing import Optional, List
from core.models import (
    ParsedPacket,
    PacketMetadata,
    LayerInfo,
    ProtocolType,
)
from core.protocols.ethernet import decode_ethernet
from core.protocols.arp import decode_arp
from core.protocols.ipv4 import decode_ipv4
from core.protocols.ipv6 import decode_ipv6
from core.protocols.icmp import decode_icmp
from core.protocols.tcp import decode_tcp
from core.protocols.udp import decode_udp
from core.protocols.dns import decode_dns
from core.protocols.http import decode_http
from core.protocols.tls import decode_tls
from core.protocols.dhcp import decode_dhcp


class PacketDecoder:
    """Multi-layer binary packet decoding engine."""

    def __init__(self):
        pass

    def decode_packet(self, raw_bytes: bytes, packet_id: int, timestamp: float) -> ParsedPacket:
        """Decodes raw binary packet frame into structured multi-layer object."""
        layers: List[LayerInfo] = []
        offset = 0
        total_len = len(raw_bytes)

        src_mac = None
        dst_mac = None
        src_ip = None
        dst_ip = None
        src_port = None
        dst_port = None
        highest_proto = "Raw"
        info_summary = ""
        tcp_flags = []

        # 1. Layer 2: Ethernet
        eth_layer, ethertype, offset = decode_ethernet(raw_bytes, offset)
        if eth_layer:
            layers.append(eth_layer)
            highest_proto = "Ethernet"
            src_mac = eth_layer.fields.get("Source MAC")
            dst_mac = eth_layer.fields.get("Destination MAC")

            # 2. Layer 3: ARP or IP
            if ethertype == 0x0806:  # ARP
                arp_layer, offset = decode_arp(raw_bytes, offset)
                if arp_layer:
                    layers.append(arp_layer)
                    highest_proto = "ARP"
                    src_ip = arp_layer.fields.get("Sender IP")
                    dst_ip = arp_layer.fields.get("Target IP")
                    info_summary = arp_layer.fields.get("Summary", "ARP")

            elif ethertype == 0x0800:  # IPv4
                ip_layer, next_proto, ip_len, offset = decode_ipv4(raw_bytes, offset)
                if ip_layer:
                    layers.append(ip_layer)
                    highest_proto = "IPv4"
                    src_ip = ip_layer.fields.get("Source IP")
                    dst_ip = ip_layer.fields.get("Destination IP")
                    offset = self._decode_transport_and_apps(
                        raw_bytes, offset, next_proto, layers
                    )

            elif ethertype == 0x86DD:  # IPv6
                ip6_layer, next_proto, ip6_len, offset = decode_ipv6(raw_bytes, offset)
                if ip6_layer:
                    layers.append(ip6_layer)
                    highest_proto = "IPv6"
                    src_ip = ip6_layer.fields.get("Source IP")
                    dst_ip = ip6_layer.fields.get("Destination IP")
                    offset = self._decode_transport_and_apps(
                        raw_bytes, offset, next_proto, layers, is_ipv6=True
                    )
        else:
            # Check if raw IP packet without Ethernet header
            first_nibble = (raw_bytes[0] >> 4) if raw_bytes else 0
            if first_nibble == 4:
                ip_layer, next_proto, ip_len, offset = decode_ipv4(raw_bytes, 0)
                if ip_layer:
                    layers.append(ip_layer)
                    highest_proto = "IPv4"
                    src_ip = ip_layer.fields.get("Source IP")
                    dst_ip = ip_layer.fields.get("Destination IP")
                    offset = self._decode_transport_and_apps(
                        raw_bytes, offset, next_proto, layers
                    )

        # Extract higher layer specifics
        for layer in layers:
            highest_proto = layer.protocol.value
            if layer.protocol == ProtocolType.TCP:
                src_port = layer.fields.get("Source Port")
                dst_port = layer.fields.get("Destination Port")
                tcp_flags = [k for k, v in layer.fields.get("Flags", {}).items() if v is True]
                flags_str = layer.fields.get("Flags", {}).get("Summary", "")
                seq = layer.fields.get("Sequence Number")
                ack = layer.fields.get("Acknowledgment Number")
                info_summary = f"{src_port} -> {dst_port} {flags_str} Seq={seq} Ack={ack}"

            elif layer.protocol == ProtocolType.UDP:
                src_port = layer.fields.get("Source Port")
                dst_port = layer.fields.get("Destination Port")
                length = layer.fields.get("Length")
                info_summary = f"{src_port} -> {dst_port} Len={length}"

            elif layer.protocol == ProtocolType.ICMP or layer.protocol == ProtocolType.ICMPV6:
                info_summary = layer.fields.get("Summary", "ICMP Message")

            elif layer.protocol == ProtocolType.DNS:
                info_summary = layer.fields.get("Summary", "DNS Message")

            elif layer.protocol == ProtocolType.HTTP:
                info_summary = layer.fields.get("Summary", "HTTP Message")

            elif layer.protocol == ProtocolType.TLS:
                info_summary = layer.fields.get("Summary", "TLS Record")

            elif layer.protocol == ProtocolType.DHCP:
                info_summary = layer.fields.get("Summary", "DHCP Message")

        # Payload extraction
        payload_bytes = raw_bytes[offset:] if offset < total_len else b""
        payload_hex = payload_bytes.hex()
        payload_text = "".join(chr(b) if 32 <= b <= 126 else "." for b in payload_bytes[:512])

        metadata = PacketMetadata(
            id=packet_id,
            timestamp=timestamp,
            length=total_len,
            highest_protocol=highest_proto,
            src_mac=src_mac,
            dst_mac=dst_mac,
            src_ip=src_ip,
            dst_ip=dst_ip,
            src_port=src_port,
            dst_port=dst_port,
            info=info_summary or f"{highest_proto} packet ({total_len} bytes)",
            tcp_flags=tcp_flags,
        )

        return ParsedPacket(
            metadata=metadata,
            layers=layers,
            raw_hex=raw_bytes.hex(),
            payload_hex=payload_hex,
            payload_text=payload_text,
        )

    def _decode_transport_and_apps(
        self,
        raw_bytes: bytes,
        offset: int,
        proto_num: int,
        layers: List[LayerInfo],
        is_ipv6: bool = False,
    ) -> int:
        """Decodes Layer 4 (TCP/UDP/ICMP) and Layer 7 applications."""
        if proto_num == 1 or (is_ipv6 and proto_num == 58):  # ICMP / ICMPv6
            icmp_layer, offset = decode_icmp(raw_bytes, offset, is_ipv6=is_ipv6)
            if icmp_layer:
                layers.append(icmp_layer)
            return offset

        elif proto_num == 6:  # TCP
            tcp_layer, src_port, dst_port, _, offset = decode_tcp(raw_bytes, offset)
            if tcp_layer:
                layers.append(tcp_layer)
                
                # Check for App layer on top of TCP
                if offset < len(raw_bytes):
                    # HTTP (80, 8080, 8000, 3000, 5000) or heuristic
                    if src_port in (80, 8080, 8000, 3000, 5000) or dst_port in (80, 8080, 8000, 3000, 5000):
                        http_layer, offset = decode_http(raw_bytes, offset)
                        if http_layer:
                            layers.append(http_layer)
                            return offset

                    # TLS (443, 8443) or handshake signature
                    if src_port in (443, 8443) or dst_port in (443, 8443) or raw_bytes[offset:offset+1] in (b"\x16", b"\x17"):
                        tls_layer, offset = decode_tls(raw_bytes, offset)
                        if tls_layer:
                            layers.append(tls_layer)
                            return offset

                    # Fallback check for HTTP
                    http_layer, offset = decode_http(raw_bytes, offset)
                    if http_layer:
                        layers.append(http_layer)
            return offset

        elif proto_num == 17:  # UDP
            udp_layer, src_port, dst_port, _, offset = decode_udp(raw_bytes, offset)
            if udp_layer:
                layers.append(udp_layer)

                # DNS (Port 53)
                if src_port == 53 or dst_port == 53:
                    dns_layer, offset = decode_dns(raw_bytes, offset)
                    if dns_layer:
                        layers.append(dns_layer)
                        return offset

                # DHCP (Port 67, 68)
                if src_port in (67, 68) or dst_port in (67, 68):
                    dhcp_layer, offset = decode_dhcp(raw_bytes, offset)
                    if dhcp_layer:
                        layers.append(dhcp_layer)
                        return offset

            return offset

        return offset
