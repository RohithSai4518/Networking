"""
Dynamic Host Configuration Protocol (DHCP) Decoder (RFC 2131)
Decodes DHCP message types (Discover, Offer, Request, ACK), Client MAC, IP leases, and Option tags.
"""

import socket
import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType
from core.protocols.ethernet import format_mac


DHCP_MESSAGE_TYPES = {
    1: "DHCP Discover",
    2: "DHCP Offer",
    3: "DHCP Request",
    4: "DHCP Decline",
    5: "DHCP ACK",
    6: "DHCP NAK",
    7: "DHCP Release",
    8: "DHCP Inform",
}


def decode_dhcp_options(options_bytes: bytes) -> Dict[str, Any]:
    """Parses TLV encoded DHCP options (RFC 2132)."""
    options: Dict[str, Any] = {}
    curr = 0
    length = len(options_bytes)

    while curr < length:
        tag = options_bytes[curr]
        if tag == 0:  # Padding
            curr += 1
            continue
        if tag == 255:  # End of options
            break

        if curr + 1 >= length:
            break
        opt_len = options_bytes[curr + 1]
        curr += 2

        if curr + opt_len > length:
            break
        opt_val = options_bytes[curr : curr + opt_len]
        curr += opt_len

        if tag == 53 and opt_len == 1:  # Message Type
            msg_type = opt_val[0]
            options["Message Type"] = DHCP_MESSAGE_TYPES.get(msg_type, f"Type {msg_type}")
        elif tag == 1 and opt_len == 4:  # Subnet Mask
            options["Subnet Mask"] = socket.inet_ntoa(opt_val)
        elif tag == 3 and opt_len >= 4:  # Router / Gateway
            options["Router"] = socket.inet_ntoa(opt_val[:4])
        elif tag == 6 and opt_len >= 4:  # Domain Name Server
            dns_servers = [socket.inet_ntoa(opt_val[i : i + 4]) for i in range(0, opt_len, 4) if i + 4 <= opt_len]
            options["Domain Name Servers"] = dns_servers
        elif tag == 12:  # Host Name
            options["Host Name"] = opt_val.decode("ascii", errors="replace")
        elif tag == 50 and opt_len == 4:  # Requested IP
            options["Requested IP Address"] = socket.inet_ntoa(opt_val)
        elif tag == 51 and opt_len == 4:  # Lease Time
            lease_sec = struct.unpack("!I", opt_val)[0]
            options["IP Address Lease Time"] = f"{lease_sec} seconds"
        elif tag == 54 and opt_len == 4:  # Server Identifier
            options["DHCP Server Identifier"] = socket.inet_ntoa(opt_val)

    return options


def decode_dhcp(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int]:
    """
    Decode a DHCP/BOOTP packet.
    Returns: (LayerInfo, next_offset)
    """
    if len(data) - offset < 240:
        return None, offset

    header_bytes = data[offset : offset + 240]
    op, htype, hlen, hops, xid, secs, flags = struct.unpack("!BBBBIHH", header_bytes[:12])

    ciaddr = socket.inet_ntoa(header_bytes[12:16])
    yiaddr = socket.inet_ntoa(header_bytes[16:20])
    siaddr = socket.inet_ntoa(header_bytes[20:24])
    giaddr = socket.inet_ntoa(header_bytes[24:28])
    chaddr_raw = header_bytes[28:44]
    client_mac = format_mac(chaddr_raw[:6])

    magic_cookie = struct.unpack("!I", header_bytes[236:240])[0]
    is_dhcp = (magic_cookie == 0x63825363)

    fields: Dict[str, Any] = {
        "Message Opcode": "Boot Request (1)" if op == 1 else "Boot Reply (2)",
        "Hardware Type": f"0x{htype:02x} ({'Ethernet' if htype == 1 else 'Other'})",
        "Transaction ID": f"0x{xid:08x}",
        "Seconds Elapsed": secs,
        "Flags": f"0x{flags:04x}",
        "Client IP Address": ciaddr,
        "Your (Client) IP Address": yiaddr,
        "Next Server IP Address": siaddr,
        "Relay Agent IP Address": giaddr,
        "Client MAC Address": client_mac,
    }

    if is_dhcp and len(data) - offset > 240:
        options_bytes = data[offset + 240 :]
        decoded_opts = decode_dhcp_options(options_bytes)
        fields["DHCP Options"] = decoded_opts
        if "Message Type" in decoded_opts:
            fields["Summary"] = f"{decoded_opts['Message Type']} - Client: {client_mac}"
        else:
            fields["Summary"] = f"DHCP Message (xid: 0x{xid:08x})"
    else:
        fields["Summary"] = f"BOOTP ({'Request' if op == 1 else 'Reply'})"

    total_len = len(data) - offset
    layer = LayerInfo(
        layer_name="Dynamic Host Configuration Protocol",
        protocol=ProtocolType.DHCP,
        offset=offset,
        length=total_len,
        fields=fields,
        raw_header_hex=data[offset:].hex(),
    )

    return layer, offset + total_len
