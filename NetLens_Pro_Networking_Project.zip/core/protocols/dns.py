"""
Domain Name System (DNS) Decoder (RFC 1035)
Decodes DNS transaction ID, flags, queries, answers, and handles DNS label compression pointers.
"""

import socket
import struct
from typing import Tuple, Dict, Any, List, Optional
from core.models import LayerInfo, ProtocolType


RECORD_TYPES = {
    1: "A",
    2: "NS",
    5: "CNAME",
    6: "SOA",
    12: "PTR",
    15: "MX",
    16: "TXT",
    28: "AAAA",
    33: "SRV",
    255: "ANY",
}

RCODE_NAMES = {
    0: "No Error",
    1: "Format Error",
    2: "Server Failure",
    3: "Non-Existent Domain (NXDOMAIN)",
    4: "Not Implemented",
    5: "Query Refused",
}


def parse_dns_name(data: bytes, offset: int, start_of_dns: int) -> Tuple[str, int]:
    """
    Parses a DNS name handling standard length-prefixed labels and RFC 1035 compression pointers (0xC0).
    Returns (domain_name, next_offset).
    """
    labels = []
    curr = offset
    jumped = False
    original_next = curr
    depth = 0

    while curr < len(data) and depth < 20:
        depth += 1
        length = data[curr]
        
        if length == 0:
            if not jumped:
                original_next = curr + 1
            break

        # Check for compression pointer (top two bits 11xxxxxx = 0xC0)
        if (length & 0xC0) == 0xC0:
            if curr + 1 >= len(data):
                break
            pointer_offset = ((length & 0x3F) << 8) | data[curr + 1]
            if not jumped:
                original_next = curr + 2
                jumped = True
            curr = start_of_dns + pointer_offset
            continue

        curr += 1
        if curr + length > len(data):
            break
        labels.append(data[curr : curr + length].decode("ascii", errors="replace"))
        curr += length

    domain = ".".join(labels) if labels else "<Root>"
    next_pos = original_next if jumped else curr + 1
    return domain, next_pos


def decode_dns(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int]:
    """
    Decode a DNS packet.
    Returns: (LayerInfo, payload_offset)
    """
    if len(data) - offset < 12:
        return None, offset

    dns_start = offset
    txn_id, flags, qdcount, ancount, nscount, arcount = struct.unpack("!HHHHHH", data[offset : offset + 12])

    is_response = bool(flags & 0x8000)
    opcode = (flags >> 11) & 0x0F
    authoritative = bool(flags & 0x0400)
    truncated = bool(flags & 0x0200)
    recursion_desired = bool(flags & 0x0100)
    recursion_available = bool(flags & 0x0080)
    rcode = flags & 0x000F

    curr = offset + 12
    questions = []

    # Parse Questions
    for _ in range(qdcount):
        if curr >= len(data):
            break
        qname, curr = parse_dns_name(data, curr, dns_start)
        if curr + 4 > len(data):
            break
        qtype, qclass = struct.unpack("!HH", data[curr : curr + 4])
        curr += 4
        questions.append({
            "name": qname,
            "type": RECORD_TYPES.get(qtype, f"TYPE{qtype}"),
            "class": "IN" if qclass == 1 else f"CLASS{qclass}",
        })

    answers = []
    # Parse Answers
    for _ in range(ancount):
        if curr >= len(data):
            break
        aname, curr = parse_dns_name(data, curr, dns_start)
        if curr + 10 > len(data):
            break
        atype, aclass, attl, rdlength = struct.unpack("!HHIH", data[curr : curr + 10])
        curr += 10

        rdata_bytes = data[curr : curr + rdlength]
        rdata_str = ""

        if atype == 1 and rdlength == 4:  # A Record
            rdata_str = socket.inet_ntoa(rdata_bytes)
        elif atype == 28 and rdlength == 16:  # AAAA Record
            rdata_str = socket.inet_ntop(socket.AF_INET6, rdata_bytes)
        elif atype in (2, 5, 12):  # NS, CNAME, PTR
            rdata_str, _ = parse_dns_name(data, curr, dns_start)
        elif atype == 16:  # TXT
            rdata_str = rdata_bytes.decode("utf-8", errors="replace")
        else:
            rdata_str = f"0x{rdata_bytes.hex()}"

        curr += rdlength
        answers.append({
            "name": aname,
            "type": RECORD_TYPES.get(atype, f"TYPE{atype}"),
            "class": "IN" if aclass == 1 else f"CLASS{aclass}",
            "ttl": attl,
            "data": rdata_str,
        })

    summary_parts = []
    if is_response:
        summary_parts.append(f"Standard query response 0x{txn_id:04x}")
        if answers:
            first_ans = answers[0]
            summary_parts.append(f"{first_ans['type']} {first_ans['data']}")
        else:
            summary_parts.append(RCODE_NAMES.get(rcode, f"RCODE {rcode}"))
    else:
        summary_parts.append(f"Standard query 0x{txn_id:04x}")
        if questions:
            summary_parts.append(f"{questions[0]['type']} {questions[0]['name']}")

    fields: Dict[str, Any] = {
        "Transaction ID": f"0x{txn_id:04x}",
        "Flags": {
            "Response": is_response,
            "Opcode": opcode,
            "Authoritative": authoritative,
            "Truncated": truncated,
            "Recursion Desired": recursion_desired,
            "Recursion Available": recursion_available,
            "Reply Code": f"{rcode} ({RCODE_NAMES.get(rcode, 'Unknown')})",
        },
        "Questions Count": qdcount,
        "Answer RRs": ancount,
        "Authority RRs": nscount,
        "Additional RRs": arcount,
        "Questions": questions,
        "Answers": answers,
        "Summary": " ".join(summary_parts),
    }

    layer_len = curr - offset
    layer = LayerInfo(
        layer_name="Domain Name System",
        protocol=ProtocolType.DNS,
        offset=offset,
        length=layer_len,
        fields=fields,
        raw_header_hex=data[offset:curr].hex(),
    )

    return layer, curr
