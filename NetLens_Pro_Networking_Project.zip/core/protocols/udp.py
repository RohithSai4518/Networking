"""
User Datagram Protocol (UDP) Decoder (RFC 768)
Decodes UDP headers: Source Port, Destination Port, Length, and Checksum.
"""

import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType


def decode_udp(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int, int, int, int]:
    """
    Decode a UDP header.
    Returns: (LayerInfo, src_port, dst_port, udp_length, payload_offset)
    """
    if len(data) - offset < 8:
        return None, 0, 0, 0, offset

    src_port, dst_port, length, checksum = struct.unpack("!HHHH", data[offset : offset + 8])
    header_bytes = data[offset : offset + 8]
    raw_header_hex = header_bytes.hex()

    fields: Dict[str, Any] = {
        "Source Port": src_port,
        "Destination Port": dst_port,
        "Length": f"{length} bytes",
        "Checksum": f"0x{checksum:04x}",
    }

    layer = LayerInfo(
        layer_name="User Datagram Protocol",
        protocol=ProtocolType.UDP,
        offset=offset,
        length=8,
        fields=fields,
        raw_header_hex=raw_header_hex,
    )

    payload_offset = offset + 8
    return layer, src_port, dst_port, length, payload_offset
