"""
Ethernet II & IEEE 802.1Q Frame Decoder
Decodes standard Ethernet frame headers, MAC addresses, and EtherType payloads.
"""

import struct
from typing import Tuple, Dict, Any, Optional
from core.models import LayerInfo, ProtocolType


def format_mac(raw_bytes: bytes) -> str:
    """Format 6 raw bytes into standard colon-separated MAC address."""
    if len(raw_bytes) != 6:
        return "00:00:00:00:00:00"
    return ":".join(f"{b:02x}" for b in raw_bytes)


ETHERTYPE_MAP = {
    0x0800: "IPv4",
    0x0806: "ARP",
    0x86DD: "IPv6",
    0x8100: "802.1Q VLAN",
    0x88CC: "LLDP",
    0x8847: "MPLS Unicast",
    0x88F7: "PTP",
}


def decode_ethernet(data: bytes, offset: int = 0) -> Tuple[Optional[LayerInfo], int, int]:
    """
    Decode an Ethernet II frame header.
    Returns: (LayerInfo, ethertype, payload_offset)
    """
    if len(data) - offset < 14:
        return None, 0, offset

    dst_mac_raw = data[offset : offset + 6]
    src_mac_raw = data[offset + 6 : offset + 12]
    ethertype = struct.unpack("!H", data[offset + 12 : offset + 14])[0]
    
    current_offset = offset + 14
    vlan_id = None
    vlan_priority = None

    # Handle 802.1Q VLAN tagging (0x8100)
    if ethertype == 0x8100 and len(data) - current_offset >= 4:
        tci, ethertype = struct.unpack("!HH", data[current_offset : current_offset + 4])
        vlan_priority = (tci >> 13) & 0x07
        vlan_id = tci & 0x0FFF
        current_offset += 4

    header_len = current_offset - offset
    raw_header_hex = data[offset:current_offset].hex()

    fields: Dict[str, Any] = {
        "Destination MAC": format_mac(dst_mac_raw),
        "Source MAC": format_mac(src_mac_raw),
        "EtherType": f"0x{ethertype:04x} ({ETHERTYPE_MAP.get(ethertype, 'Unknown')})",
        "Raw EtherType": ethertype,
    }

    if vlan_id is not None:
        fields["VLAN ID"] = vlan_id
        fields["VLAN Priority"] = vlan_priority

    layer = LayerInfo(
        layer_name="Ethernet II",
        protocol=ProtocolType.ETHERNET,
        offset=offset,
        length=header_len,
        fields=fields,
        raw_header_hex=raw_header_hex,
    )

    return layer, ethertype, current_offset
