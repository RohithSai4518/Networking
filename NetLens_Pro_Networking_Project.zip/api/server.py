"""
FastAPI & WebSocket Server Engine for NetLens Pro
Handles REST management endpoints, PCAP imports/exports, and real-time WebSocket streaming.
"""

import asyncio
import io
import os
import time
from typing import List, Set, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, Response, Query
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from core.models import ParsedPacket, SecurityAnomaly
from core.protocols.decoder import PacketDecoder
from core.capture.sniffer import LiveSniffer
from core.capture.pcap import PcapReader, PcapWriter
from core.flows.tracker import FlowTracker
from core.flows.metrics import MetricsEngine
from core.security.detector import AnomalyDetector
from core.storage.ring_buffer import PacketRingBuffer


# Initialize Core Services
app = FastAPI(title="NetLens Pro - Network Protocol Analyzer & DPI Suite", version="2.0.0")

decoder = PacketDecoder()
ring_buffer = PacketRingBuffer(capacity=50000)
flow_tracker = FlowTracker()
metrics_engine = MetricsEngine(window_seconds=2.0)
anomaly_detector = AnomalyDetector()

# WebSocket Connection Pool
active_websockets: Set[WebSocket] = set()
event_loop: Optional[asyncio.AbstractEventLoop] = None


def packet_ingest_callback(raw_bytes: bytes, timestamp: float):
    """Invoked synchronously by sniffer for each captured packet."""
    global event_loop
    packet_id = ring_buffer.get_count() + 1
    packet: ParsedPacket = decoder.decode_packet(raw_bytes, packet_id, timestamp)
    
    # 1. Store in ring buffer
    ring_buffer.add_packet(packet)

    # 2. Update flows
    flow = flow_tracker.process_packet(packet)

    # 3. Update telemetry metrics
    metrics_engine.record_packet(packet)

    # 4. Security anomaly analysis
    anomalies = anomaly_detector.analyze_packet(packet)

    # 5. Broadcast to connected WebSocket clients if loop exists
    if active_websockets and event_loop and event_loop.is_running():
        msg = {
            "type": "packet",
            "packet": packet.to_dict(include_raw=False),
            "anomalies": [a.to_dict() for a in anomalies],
        }
        asyncio.run_coroutine_threadsafe(broadcast_message(msg), event_loop)


sniffer = LiveSniffer(packet_callback=packet_ingest_callback)


async def broadcast_message(message: dict):
    """Broadcasts JSON message to all connected clients."""
    disconnected = set()
    for ws in list(active_websockets):
        try:
            await ws.send_json(message)
        except Exception:
            disconnected.add(ws)
    for ws in disconnected:
        active_websockets.discard(ws)


async def telemetry_broadcast_loop():
    """Periodically pushes real-time bandwidth metrics and stats to UI (every 500ms)."""
    while True:
        await asyncio.sleep(0.5)
        if active_websockets:
            stats = metrics_engine.get_stats(
                active_flows=len(flow_tracker.flows),
                anomaly_count=len(anomaly_detector.anomalies),
            )
            msg = {
                "type": "telemetry",
                "stats": stats.to_dict(),
            }
            await broadcast_message(msg)


@app.on_event("startup")
async def startup_event():
    global event_loop
    event_loop = asyncio.get_event_loop()
    # Auto-start traffic in synthetic mode by default
    sniffer.start(use_synthetic=True)
    asyncio.create_task(telemetry_broadcast_loop())


@app.on_event("shutdown")
def shutdown_event():
    sniffer.stop()


# --- REST API Endpoints ---

@app.get("/api/status")
def get_status():
    return {
        "is_capturing": sniffer.is_running,
        "is_synthetic": sniffer.is_synthetic,
        "total_packets": ring_buffer.get_count(),
        "total_flows": len(flow_tracker.flows),
        "total_anomalies": len(anomaly_detector.anomalies),
    }


@app.post("/api/capture/start")
def start_capture(synthetic: bool = Query(True)):
    sniffer.stop()
    sniffer.start(use_synthetic=synthetic)
    return {"status": "started", "synthetic": sniffer.is_synthetic}


@app.post("/api/capture/stop")
def stop_capture():
    sniffer.stop()
    return {"status": "stopped"}


@app.post("/api/capture/clear")
def clear_capture():
    ring_buffer.clear()
    flow_tracker.clear()
    metrics_engine.clear()
    anomaly_detector.clear()
    return {"status": "cleared"}


@app.post("/api/capture/simulate-scan")
def simulate_scan():
    sniffer.inject_port_scan_simulation()
    return {"status": "simulated_port_scan_injected"}


@app.get("/api/packets")
def list_packets(
    filter: str = Query("", description="BPF-like filter expression"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
):
    packets = ring_buffer.query_packets(filter_expr=filter, limit=limit, offset=offset)
    return {
        "total_buffered": ring_buffer.get_count(),
        "filter": filter,
        "count": len(packets),
        "packets": [p.to_dict(include_raw=False) for p in packets],
    }


@app.get("/api/packets/{packet_id}")
def get_packet_details(packet_id: int):
    pkt = ring_buffer.get_packet_by_id(packet_id)
    if not pkt:
        return JSONResponse(status_code=404, content={"error": "Packet not found"})
    return pkt.to_dict(include_raw=True)


@app.get("/api/flows")
def list_flows():
    return {
        "count": len(flow_tracker.flows),
        "flows": [f.to_dict() for f in flow_tracker.get_all_flows()[:100]],
    }


@app.get("/api/flows/{flow_key:path}/stream")
def get_flow_stream(flow_key: str):
    data = flow_tracker.get_flow_reassembled_data(flow_key)
    return {
        "flow_key": flow_key,
        "client_to_server": data["client_to_server"],
        "server_to_client": data["server_to_client"],
    }


@app.get("/api/anomalies")
def list_anomalies():
    return {
        "count": len(anomaly_detector.anomalies),
        "anomalies": [a.to_dict() for a in anomaly_detector.get_all_anomalies()],
    }


@app.get("/api/stats")
def get_stats():
    stats = metrics_engine.get_stats(
        active_flows=len(flow_tracker.flows),
        anomaly_count=len(anomaly_detector.anomalies),
    )
    return stats.to_dict()


@app.get("/api/pcap/export")
def export_pcap():
    """Generates standard .pcap binary file for download."""
    raw_packets = ring_buffer.get_all_raw_bytes()
    buf = io.BytesIO()
    writer = PcapWriter(buf)
    for raw in raw_packets:
        writer.write_packet(raw)

    buf.seek(0)
    return Response(
        content=buf.getvalue(),
        media_type="application/vnd.tcpdump.pcap",
        headers={"Content-Disposition": f"attachment; filename=netlens_capture_{int(time.time())}.pcap"},
    )


@app.post("/api/pcap/upload")
async def upload_pcap(file: UploadFile = File(...)):
    """Uploads and analyzes an external .pcap file."""
    content = await file.read()
    buf = io.BytesIO(content)
    try:
        reader = PcapReader(buf)
        packets = reader.read_packets()
        # Clear existing before loading imported capture
        clear_capture()
        for ts, raw in packets:
            packet_ingest_callback(raw, ts)
        return {"status": "imported", "packet_count": len(packets)}
    except Exception as e:
        return JSONResponse(status_code=400, content={"error": f"Failed to parse PCAP: {str(e)}"})


# --- WebSocket Live Streaming Channel ---

@app.websocket("/ws/live")
async def websocket_live_feed(websocket: WebSocket):
    await websocket.accept()
    active_websockets.add(websocket)
    try:
        while True:
            # Handle incoming ping / commands from client
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        active_websockets.discard(websocket)
    except Exception:
        active_websockets.discard(websocket)


# Mount Static Files and Web App Dashboard
web_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "web")
app.mount("/static", StaticFiles(directory=os.path.join(web_dir, "static")), name="static")


@app.get("/", response_class=HTMLResponse)
def serve_index():
    index_path = os.path.join(web_dir, "templates", "index.html")
    with open(index_path, "r", encoding="utf-8") as f:
        return f.read()
