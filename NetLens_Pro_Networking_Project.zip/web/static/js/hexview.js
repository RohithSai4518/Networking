/**
 * Wireshark-Style Hex & ASCII Dual-Pane Visualizer
 */

function renderHexDump(containerElement, rawHex) {
    if (!rawHex) {
        containerElement.innerHTML = '<div class="empty-state">No binary payload in this packet.</div>';
        return;
    }

    const rawBytes = [];
    for (let i = 0; i < rawHex.length; i += 2) {
        rawBytes.push(parseInt(rawHex.substr(i, 2), 16));
    }

    let html = '';
    const bytesPerRow = 16;

    for (let offset = 0; offset < rawBytes.length; offset += bytesPerRow) {
        const chunk = rawBytes.slice(offset, offset + bytesPerRow);
        
        // 1. Format Offset
        const offsetStr = offset.toString(16).padStart(4, '0');

        // 2. Format Hex Bytes (grouped in two 8-byte chunks)
        const hexParts = [];
        for (let i = 0; i < bytesPerRow; i++) {
            if (i < chunk.length) {
                hexParts.push(chunk[i].toString(16).padStart(2, '0'));
            } else {
                hexParts.push('  ');
            }
            if (i === 7) hexParts.push(' ');
        }
        const hexStr = hexParts.join(' ');

        // 3. Format ASCII chars
        let asciiStr = '';
        for (let i = 0; i < chunk.length; i++) {
            const b = chunk[i];
            if (b >= 32 && b <= 126) {
                asciiStr += String.fromCharCode(b);
            } else {
                asciiStr += '.';
            }
        }

        html += `
            <div class="hex-row">
                <span class="hex-offset">${offsetStr}</span>
                <span class="hex-bytes">${hexStr}</span>
                <span class="hex-ascii">${escapeHtml(asciiStr)}</span>
            </div>
        `;
    }

    containerElement.innerHTML = html;
}

function escapeHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
