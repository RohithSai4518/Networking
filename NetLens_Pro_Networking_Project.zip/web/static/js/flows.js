/**
 * Network Conversation Flows & Stream Reconstruction Controller
 */

class FlowController {
    constructor() {
        this.flowTableBody = document.getElementById('flow-table-body');
        this.btnRefresh = document.getElementById('btn-refresh-flows');
        this.modal = document.getElementById('stream-modal');
        this.btnCloseModal = document.getElementById('btn-close-modal');
        this.modalTitle = document.getElementById('modal-flow-title');
        this.streamClient = document.getElementById('stream-client-text');
        this.streamServer = document.getElementById('stream-server-text');

        this.initEvents();
    }

    initEvents() {
        if (this.btnRefresh) {
            this.btnRefresh.addEventListener('click', () => this.fetchFlows());
        }

        if (this.btnCloseModal) {
            this.btnCloseModal.addEventListener('click', () => {
                this.modal.classList.remove('active');
            });
        }

        window.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.modal.classList.remove('active');
            }
        });
    }

    async fetchFlows() {
        try {
            const res = await fetch('/api/flows');
            const data = await res.json();
            this.renderFlows(data.flows);
            const countElem = document.getElementById('tab-flows-count');
            if (countElem) countElem.innerText = data.count;
        } catch (err) {
            console.error('Error fetching flows:', err);
        }
    }

    renderFlows(flows) {
        if (!this.flowTableBody) return;
        if (!flows || flows.length === 0) {
            this.flowTableBody.innerHTML = '<tr><td colspan="9" class="empty-state">No active network conversations tracked yet.</td></tr>';
            return;
        }

        let html = '';
        flows.forEach(flow => {
            const protoClass = `badge-proto row-${flow.protocol.toLowerCase()}`;
            html += `
                <tr>
                    <td><span class="${protoClass}">${escapeHtml(flow.protocol)}</span></td>
                    <td><strong>${escapeHtml(flow.src)}</strong></td>
                    <td><strong>${escapeHtml(flow.dst)}</strong></td>
                    <td><span class="badge">${escapeHtml(flow.application)}</span></td>
                    <td><span class="stat-value">${escapeHtml(flow.state)}</span></td>
                    <td>${flow.duration}s</td>
                    <td>${flow.packets_forward} / ${flow.packets_reverse}</td>
                    <td>${formatBytes(flow.bytes_forward)} / ${formatBytes(flow.bytes_reverse)}</td>
                    <td>
                        <button class="btn btn-sm btn-outline" onclick="flowController.openStreamModal('${encodeURIComponent(flow.key)}')">
                            Follow Stream
                        </button>
                    </td>
                </tr>
            `;
        });

        this.flowTableBody.innerHTML = html;
    }

    async openStreamModal(encodedKey) {
        try {
            const key = decodeURIComponent(encodedKey);
            this.modalTitle.innerText = `Reassembled TCP Stream: ${key}`;
            this.streamClient.innerText = 'Loading reconstructed payload stream...';
            this.streamServer.innerText = '';
            this.modal.classList.add('active');

            const res = await fetch(`/api/flows/${encodeURIComponent(key)}/stream`);
            const data = await res.json();

            this.streamClient.innerText = data.client_to_server || '(No client payload text)';
            this.streamServer.innerText = data.server_to_client || '(No server payload text)';
        } catch (err) {
            this.streamClient.innerText = `Failed to load stream: ${err}`;
        }
    }
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

window.flowController = new FlowController();
