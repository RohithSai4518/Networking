/**
 * NetLens Pro - Main Web Dashboard Application
 */

class NetLensApp {
    constructor() {
        this.ws = null;
        this.isPaused = false;
        this.currentFilter = '';
        this.selectedPacketId = null;
        this.displayedPackets = [];
        this.maxTableRows = 300;

        // Elements
        this.packetTableBody = document.getElementById('packet-table-body');
        this.treeContainer = document.getElementById('tree-container');
        this.hexBody = document.getElementById('hex-body');
        this.inspectorTitle = document.getElementById('inspector-title');
        this.packetSizeBadge = document.getElementById('packet-size-badge');

        this.btnToggleCapture = document.getElementById('btn-toggle-capture');
        this.btnCaptureText = document.getElementById('btn-capture-text');
        this.liveIndicator = document.getElementById('live-indicator');
        this.btnClear = document.getElementById('btn-clear');
        this.btnSimulateScan = document.getElementById('btn-simulate-scan');
        this.btnExportPcap = document.getElementById('btn-export-pcap');
        this.pcapFileInput = document.getElementById('pcap-file-input');

        this.filterInput = document.getElementById('filter-query');
        this.btnApplyFilter = document.getElementById('btn-apply-filter');
        this.btnClearFilter = document.getElementById('btn-clear-filter');

        this.initTabs();
        this.initControls();
        this.initWebSocket();
        this.fetchInitialPackets();
    }

    initTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

                btn.classList.add('active');
                const targetId = btn.getAttribute('data-tab');
                const targetPane = document.getElementById(targetId);
                if (targetPane) targetPane.classList.add('active');

                if (targetId === 'tab-flows' && window.flowController) {
                    window.flowController.fetchFlows();
                } else if (targetId === 'tab-security') {
                    this.fetchAnomalies();
                }
            });
        });
    }

    initControls() {
        // Play / Pause
        this.btnToggleCapture.addEventListener('click', () => {
            this.isPaused = !this.isPaused;
            if (this.isPaused) {
                this.btnCaptureText.innerText = 'Resume Live';
                this.liveIndicator.classList.remove('live-pulsing');
                this.liveIndicator.style.backgroundColor = '#d29922';
            } else {
                this.btnCaptureText.innerText = 'Pause Live';
                this.liveIndicator.classList.add('live-pulsing');
                this.liveIndicator.style.backgroundColor = '#2ea043';
            }
        });

        // Clear
        this.btnClear.addEventListener('click', async () => {
            await fetch('/api/capture/clear', { method: 'POST' });
            this.packetTableBody.innerHTML = '';
            this.displayedPackets = [];
            this.treeContainer.innerHTML = '<div class="empty-state">Buffer cleared. Waiting for new packets...</div>';
            this.hexBody.innerHTML = '<div class="empty-state">Raw byte payload dump will appear here.</div>';
            this.inspectorTitle.innerText = 'Select a packet to inspect protocol layers';
            this.packetSizeBadge.innerText = '';
        });

        // Simulate Attack
        this.btnSimulateScan.addEventListener('click', async () => {
            await fetch('/api/capture/simulate-scan', { method: 'POST' });
        });

        // Export PCAP
        this.btnExportPcap.addEventListener('click', () => {
            window.location.href = '/api/pcap/export';
        });

        // Import PCAP
        this.pcapFileInput.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const formData = new FormData();
            formData.append('file', file);
            try {
                const res = await fetch('/api/pcap/upload', {
                    method: 'POST',
                    body: formData,
                });
                const result = await res.json();
                if (res.ok) {
                    this.fetchInitialPackets();
                    alert(`Successfully imported ${result.packet_count} packets from PCAP.`);
                } else {
                    alert(`PCAP Import Error: ${result.error}`);
                }
            } catch (err) {
                alert(`Upload failed: ${err}`);
            }
        });

        // Filters
        this.btnApplyFilter.addEventListener('click', () => {
            this.currentFilter = this.filterInput.value.trim();
            this.fetchInitialPackets();
        });

        this.filterInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                this.currentFilter = this.filterInput.value.trim();
                this.fetchInitialPackets();
            }
        });

        this.btnClearFilter.addEventListener('click', () => {
            this.filterInput.value = '';
            this.currentFilter = '';
            document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
            document.querySelector('.filter-pill[data-filter=""]').classList.add('active');
            this.fetchInitialPackets();
        });

        // Quick filter pills
        document.querySelectorAll('.filter-pill').forEach(pill => {
            pill.addEventListener('click', () => {
                document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
                pill.classList.add('active');
                const filterVal = pill.getAttribute('data-filter');
                this.filterInput.value = filterVal;
                this.currentFilter = filterVal;
                this.fetchInitialPackets();
            });
        });

        // Clear anomalies button
        const btnClearAnomalies = document.getElementById('btn-clear-anomalies');
        if (btnClearAnomalies) {
            btnClearAnomalies.addEventListener('click', () => {
                const list = document.getElementById('anomalies-list');
                if (list) list.innerHTML = '<div class="empty-state">No security anomalies detected. System running normally.</div>';
            });
        }
    }

    initWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws/live`;

        this.ws = new WebSocket(wsUrl);

        this.ws.onmessage = (event) => {
            if (this.isPaused) return;
            try {
                const msg = JSON.parse(event.data);
                if (msg.type === 'packet') {
                    this.handleNewPacket(msg.packet, msg.anomalies);
                } else if (msg.type === 'telemetry') {
                    this.handleTelemetry(msg.stats);
                }
            } catch (err) {
                console.error('WS parse error:', err);
            }
        };

        this.ws.onclose = () => {
            setTimeout(() => this.initWebSocket(), 2000);
        };
    }

    async fetchInitialPackets() {
        try {
            const res = await fetch(`/api/packets?filter=${encodeURIComponent(this.currentFilter)}&limit=100`);
            const data = await res.json();
            this.packetTableBody.innerHTML = '';
            this.displayedPackets = [];
            data.packets.forEach(p => this.appendPacketRow(p.metadata, false));
        } catch (err) {
            console.error('Error fetching packets:', err);
        }
    }

    handleNewPacket(packet, anomalies) {
        if (!this.matchesCurrentFilter(packet.metadata)) return;
        this.appendPacketRow(packet.metadata, true);
        if (anomalies && anomalies.length > 0) {
            this.renderNewAnomalies(anomalies);
        }
    }

    matchesCurrentFilter(meta) {
        if (!this.currentFilter) return true;
        const q = this.currentFilter.toLowerCase();
        if (q === 'threat' || q === 'anomaly') return meta.is_anomaly;
        if (q === 'tcp' || q === 'udp' || q === 'icmp' || q === 'arp' || q === 'dns' || q === 'http' || q === 'tls') {
            return meta.highest_protocol.toLowerCase().includes(q);
        }
        return true;
    }

    appendPacketRow(meta, prepend = true) {
        const row = document.createElement('tr');
        row.id = `pkt-row-${meta.id}`;
        
        const protoLower = meta.highest_protocol.toLowerCase();
        let rowClass = `row-${protoLower}`;
        if (meta.is_anomaly) rowClass = 'row-anomaly';
        row.className = rowClass;

        row.innerHTML = `
            <td>${meta.id}</td>
            <td>${meta.timestamp_formatted}</td>
            <td><strong>${escapeHtml(meta.src_ip)}</strong></td>
            <td><strong>${escapeHtml(meta.dst_ip)}</strong></td>
            <td><span class="badge-proto">${escapeHtml(meta.highest_protocol)}</span></td>
            <td>${meta.length} B</td>
            <td title="${escapeHtml(meta.info)}">${escapeHtml(meta.info)}</td>
        `;

        row.addEventListener('click', () => this.selectPacket(meta.id, row));

        if (prepend && this.packetTableBody.firstChild) {
            this.packetTableBody.insertBefore(row, this.packetTableBody.firstChild);
        } else {
            this.packetTableBody.appendChild(row);
        }

        // Limit maximum rendered rows in DOM to prevent browser slowdown
        while (this.packetTableBody.children.length > this.maxTableRows) {
            this.packetTableBody.removeChild(this.packetTableBody.lastChild);
        }
    }

    async selectPacket(packetId, rowElement) {
        document.querySelectorAll('#packet-table-body tr').forEach(r => r.classList.remove('selected'));
        if (rowElement) rowElement.classList.add('selected');
        this.selectedPacketId = packetId;

        try {
            const res = await fetch(`/api/packets/${packetId}`);
            const packet = await res.json();
            this.renderPacketDetails(packet);
        } catch (err) {
            console.error('Error fetching packet details:', err);
        }
    }

    renderPacketDetails(packet) {
        const meta = packet.metadata;
        this.inspectorTitle.innerText = `Frame ${meta.id}: ${meta.highest_protocol} (${meta.length} bytes on wire)`;
        this.packetSizeBadge.innerText = `${meta.length} Bytes`;

        // Render Protocol Tree
        let treeHtml = '';
        (packet.layers || []).forEach((layer, idx) => {
            treeHtml += `
                <div class="layer-node">
                    <div class="layer-header" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'flex' : 'none'">
                        <span>▼ ${escapeHtml(layer.layer_name)}</span>
                        <span style="font-size: 0.72rem; color: #8b949e;">${layer.length} bytes</span>
                    </div>
                    <div class="layer-fields">
            `;

            for (const [key, val] of Object.entries(layer.fields || {})) {
                let valFormatted = val;
                if (typeof val === 'object' && val !== null) {
                    valFormatted = JSON.stringify(val);
                }
                treeHtml += `
                    <div class="field-item">
                        <span class="field-key">${escapeHtml(key)}:</span>
                        <span class="field-val">${escapeHtml(String(valFormatted))}</span>
                    </div>
                `;
            }

            treeHtml += `</div></div>`;
        });

        this.treeContainer.innerHTML = treeHtml || '<div class="empty-state">No layer headers decoded.</div>';

        // Render Hex Dump
        renderHexDump(this.hexBody, packet.raw_hex);
    }

    handleTelemetry(stats) {
        document.getElementById('stat-mbps').innerText = `${stats.mbps.toFixed(3)} Mbps`;
        document.getElementById('stat-pps').innerText = `${Math.round(stats.packets_per_second)} pkt/s`;
        document.getElementById('stat-total-packets').innerText = stats.total_packets.toLocaleString();
        document.getElementById('stat-flows').innerText = stats.active_flow_count;
        document.getElementById('stat-anomalies').innerText = stats.anomaly_count;

        const countBadge = document.getElementById('tab-anomalies-count');
        if (countBadge) countBadge.innerText = stats.anomaly_count;

        // Update Charts
        if (window.netLensCharts) {
            window.netLensCharts.updateThroughput(stats.bytes_per_second / 1024);
            window.netLensCharts.renderProtocolDistribution(stats.protocol_distribution);
            window.netLensCharts.renderBarChart('chart-top-sources', stats.top_sources, 'Sources');
            window.netLensCharts.renderBarChart('chart-top-dests', stats.top_destinations, 'Destinations');
        }
    }

    async fetchAnomalies() {
        try {
            const res = await fetch('/api/anomalies');
            const data = await res.json();
            this.renderAnomaliesList(data.anomalies);
        } catch (err) {
            console.error('Error fetching anomalies:', err);
        }
    }

    renderAnomaliesList(anomalies) {
        const list = document.getElementById('anomalies-list');
        if (!list) return;

        if (!anomalies || anomalies.length === 0) {
            list.innerHTML = '<div class="empty-state">No security anomalies detected. System running normally.</div>';
            return;
        }

        let html = '';
        anomalies.forEach(a => {
            html += `
                <div class="anomaly-card">
                    <div class="anomaly-header">
                        <span class="anomaly-title">${escapeHtml(a.title)}</span>
                        <div>
                            <span class="badge-sev badge-${a.severity}">${a.severity}</span>
                            <span style="font-size: 0.75rem; color: #8b949e; margin-left: 8px;">${a.timestamp_formatted}</span>
                        </div>
                    </div>
                    <div class="anomaly-desc">${escapeHtml(a.description)}</div>
                    <div style="font-size: 0.78rem; color: #8b949e; margin-bottom: 6px;">
                        <strong>Source Host:</strong> ${escapeHtml(a.source_ip)} | <strong>Target:</strong> ${escapeHtml(a.target_ip)}
                    </div>
                    ${a.remediation_tip ? `<div class="anomaly-remediation">💡 <strong>Remediation:</strong> ${escapeHtml(a.remediation_tip)}</div>` : ''}
                </div>
            `;
        });
        list.innerHTML = html;
    }

    renderNewAnomalies(anomalies) {
        const list = document.getElementById('anomalies-list');
        if (!list) return;
        anomalies.forEach(a => {
            const card = document.createElement('div');
            card.className = 'anomaly-card';
            card.innerHTML = `
                <div class="anomaly-header">
                    <span class="anomaly-title">${escapeHtml(a.title)}</span>
                    <div>
                        <span class="badge-sev badge-${a.severity}">${a.severity}</span>
                        <span style="font-size: 0.75rem; color: #8b949e; margin-left: 8px;">${a.timestamp_formatted}</span>
                    </div>
                </div>
                <div class="anomaly-desc">${escapeHtml(a.description)}</div>
                <div style="font-size: 0.78rem; color: #8b949e; margin-bottom: 6px;">
                    <strong>Source Host:</strong> ${escapeHtml(a.source_ip)} | <strong>Target:</strong> ${escapeHtml(a.target_ip)}
                </div>
                ${a.remediation_tip ? `<div class="anomaly-remediation">💡 <strong>Remediation:</strong> ${escapeHtml(a.remediation_tip)}</div>` : ''}
            `;
            if (list.querySelector('.empty-state')) {
                list.innerHTML = '';
            }
            list.insertBefore(card, list.firstChild);
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.netLensApp = new NetLensApp();
});
