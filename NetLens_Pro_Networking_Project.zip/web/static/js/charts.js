/**
 * Real-Time Canvas Chart Engine (Pure Native Canvas - No external dependencies)
 */

class NetLensCharts {
    constructor() {
        this.throughputHistory = [];
        this.maxHistoryPoints = 30;
    }

    updateThroughput(kbps) {
        this.throughputHistory.push(kbps);
        if (this.throughputHistory.length > this.maxHistoryPoints) {
            this.throughputHistory.shift();
        }
        this.renderThroughputChart();
    }

    renderThroughputChart() {
        const canvas = document.getElementById('chart-throughput');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width;
        const h = canvas.height;

        ctx.clearRect(0, 0, w, h);

        // Draw gridlines
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        for (let y = 0; y < h; y += 40) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
        }

        if (this.throughputHistory.length < 2) return;

        const maxVal = Math.max(...this.throughputHistory, 10);
        const stepX = w / (this.maxHistoryPoints - 1);

        // Draw filled gradient area
        const gradient = ctx.createLinearGradient(0, 0, 0, h);
        gradient.addColorStop(0, 'rgba(47, 129, 247, 0.4)');
        gradient.addColorStop(1, 'rgba(47, 129, 247, 0.0)');

        ctx.beginPath();
        ctx.moveTo(0, h);

        this.throughputHistory.forEach((val, i) => {
            const x = i * stepX;
            const y = h - (val / maxVal) * (h - 20) - 10;
            ctx.lineTo(x, y);
        });

        ctx.lineTo((this.throughputHistory.length - 1) * stepX, h);
        ctx.closePath();
        ctx.fillStyle = gradient;
        ctx.fill();

        // Draw line
        ctx.beginPath();
        this.throughputHistory.forEach((val, i) => {
            const x = i * stepX;
            const y = h - (val / maxVal) * (h - 20) - 10;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Value text
        const latest = this.throughputHistory[this.throughputHistory.length - 1] || 0;
        ctx.fillStyle = '#e6edf3';
        ctx.font = '12px "Fira Code"';
        ctx.fillText(`Current: ${latest.toFixed(1)} KB/s | Peak: ${maxVal.toFixed(1)} KB/s`, 10, 20);
    }

    renderProtocolDistribution(distribution) {
        const canvas = document.getElementById('chart-protocols');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width;
        const h = canvas.height;
        ctx.clearRect(0, 0, w, h);

        const entries = Object.entries(distribution || {});
        const total = entries.reduce((acc, [, count]) => acc + count, 0);
        if (total === 0) return;

        const colors = ['#2f81f7', '#38bdf8', '#2ea043', '#a371f7', '#d29922', '#f85149', '#eb73ee'];
        const centerX = 120;
        const centerY = h / 2;
        const radius = 70;
        const innerRadius = 40;

        let startAngle = 0;

        entries.forEach(([proto, count], i) => {
            const sliceAngle = (count / total) * 2 * Math.PI;
            const color = colors[i % colors.length];

            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
            ctx.arc(centerX, centerY, innerRadius, startAngle + sliceAngle, startAngle, true);
            ctx.closePath();
            ctx.fillStyle = color;
            ctx.fill();

            // Draw Legend on right
            const legendY = 30 + i * 22;
            if (legendY < h - 10) {
                ctx.fillStyle = color;
                ctx.fillRect(250, legendY - 10, 12, 12);
                ctx.fillStyle = '#e6edf3';
                ctx.font = '11px "Inter"';
                const pct = ((count / total) * 100).toFixed(1);
                ctx.fillText(`${proto}: ${count} (${pct}%)`, 270, legendY);
            }

            startAngle += sliceAngle;
        });
    }

    renderBarChart(canvasId, dataDict, label) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const w = canvas.width;
        const h = canvas.height;
        ctx.clearRect(0, 0, w, h);

        const entries = Object.entries(dataDict || {}).slice(0, 5);
        if (entries.length === 0) return;

        const maxVal = Math.max(...entries.map(([, c]) => c), 1);
        const barHeight = 22;
        const gap = 14;

        entries.forEach(([key, count], i) => {
            const y = 30 + i * (barHeight + gap);
            const barWidth = (count / maxVal) * (w - 220);

            // Label
            ctx.fillStyle = '#8b949e';
            ctx.font = '11px "Fira Code"';
            ctx.fillText(key, 10, y + 15);

            // Bar
            ctx.fillStyle = '#2f81f7';
            ctx.fillRect(160, y, barWidth, barHeight);

            // Value
            ctx.fillStyle = '#e6edf3';
            ctx.fillText(`${count} pkts`, 170 + barWidth, y + 15);
        });
    }
}

window.netLensCharts = new NetLensCharts();
